//////////////////////////////////////////////////////////////////////////////////////////
// Weapons
//////////////////////////////////////////////////////////////////////////////////////////
// LMGs 
class IP_MMG_01_SnowHex_F					 { quality = 3; price = 150; };

// Snipers 
class IP_srifle_DMR_03_SnowHex_F					 { quality = 3; price = 150; };
class IP_srifle_DMR_04_SnowHex_F					 { quality = 3; price = 150; };
class IP_srifle_DMR_05_SnowHex_F					 { quality = 3; price = 150; };

// Launchers 
class IP_launch_O_Titan_short_snw_F					 { quality = 3; price = 150; };
class IP_launch_O_Titan_snw_F					 { quality = 3; price = 150; };

// Uniforms 
class IP_U_O_CombatUniform_SnowTiger					 { quality = 3; price = 150; };
class IP_U_O_CombatUniform_SnowHex					 { quality = 3; price = 150; };
class IP_U_O_OfficerUniform_SnowTiger					 { quality = 3; price = 150; };
class IP_U_O_OfficerUniform_SnowHex					 { quality = 3; price = 150; };
class IP_U_O_HeliPilotCoveralls_SnowHex					 { quality = 3; price = 150; };
class IP_U_O_PilotCoveralls_SnowHex					 { quality = 3; price = 150; };
class IP_U_O_Wetsuit_SnowHex					 { quality = 3; price = 150; };

// Headgear / Masks 
class IP_H_Beret_02CSAT					 { quality = 3; price = 150; };
class IP_H_Beret_02SnowTiger					 { quality = 3; price = 150; };
class IP_H_HelmetO_SnowTiger					 { quality = 3; price = 150; };
class IP_H_HelmetLeaderO_SnowTiger					 { quality = 3; price = 150; };
class IP_H_HelmetO_SnowHex					 { quality = 3; price = 150; };
class IP_H_HelmetLeaderO_SnowHex					 { quality = 3; price = 150; };
class IP_H_HelmetSpecO_SnowTiger					 { quality = 3; price = 150; };
class IP_H_HelmetSpecO_SnowHex					 { quality = 3; price = 150; };
class IP_H_MilCap_HexSnow					 { quality = 3; price = 150; };
class IP_H_MilCap_SnowTiger					 { quality = 3; price = 150; };
class IP_H_Booniehat_HexSnow					 { quality = 3; price = 150; };
class IP_H_Booniehat_SnowTiger					 { quality = 3; price = 150; };
class IP_H_PilotHelmetFighter_O_Snow					 { quality = 3; price = 150; };
class IP_H_PilotHelmetHeli_O_Snow					 { quality = 3; price = 150; };
class IP_H_CrewHelmetHeli_O_Snow					 { quality = 3; price = 150; };
class IP_H_HelmetCrew_O_Snow					 { quality = 3; price = 150; };

// Vests 
class IP_V_HarnessO_gryST					 { quality = 3; price = 150; };
class IP_V_HarnessOGL_gryST					 { quality = 3; price = 150; };
class IP_V_HarnessOSpec_gryST					 { quality = 3; price = 150; };
class IP_V_PlateCarrierGL_rgrSnowHex					 { quality = 3; price = 150; };
class IP_V_PlateCarrierGL_rgrSnowTiger					 { quality = 3; price = 150; };
class IP_V_PlateCarrierSpec_rgrSnowHex					 { quality = 3; price = 150; };
class IP_V_PlateCarrierSpec_rgrSnowTiger					 { quality = 3; price = 150; };
class IP_V_TacVest_SnowHex					 { quality = 3; price = 150; };
class IP_V_TacVest_SnowTiger					 { quality = 3; price = 150; };
class IP_V_BandollierO_snw					 { quality = 3; price = 150; };
class IP_V_RebreatherIR_ST					 { quality = 3; price = 150; };

// Backpacks
class IP_B_AssaultPack_SnowHex						 { quality = 3; price = 150; };
class IP_B_AssaultPack_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Carryall_AAA_SnowHex						 { quality = 3; price = 150; };
class IP_B_Carryall_AAA_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Carryall_AAR_SnowHex						 { quality = 3; price = 150; };
class IP_B_Carryall_AAR_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Carryall_AAT_SnowHex						 { quality = 3; price = 150; };
class IP_B_Carryall_AAT_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Carryall_Ammo_SnowHex						 { quality = 3; price = 150; };
class IP_B_Carryall_Ammo_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Carryall_Eng_SnowHex						 { quality = 3; price = 150; };
class IP_B_Carryall_Eng_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Carryall_Exp_SnowHex						 { quality = 3; price = 150; };
class IP_B_Carryall_Exp_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Carryall_SnowHex						 { quality = 3; price = 150; };
class IP_B_Carryall_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_AA_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_AA_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_AT_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_AT_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_LAT_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_LAT_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_Medic_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_Medic_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_ReconExp_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_ReconExp_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_ReconMedic_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_ReconMedic_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_Repair_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_Repair_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_RPG_AT_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_RPG_AT_SnowTiger						 { quality = 3; price = 150; };
class IP_B_FieldPack_SnowHex						 { quality = 3; price = 150; };
class IP_B_FieldPack_SnowTiger						 { quality = 3; price = 150; };
class IP_B_Kitbag_SnowHex						 { quality = 3; price = 150; };
class IP_B_Kitbag_SnowTiger						 { quality = 3; price = 150; };
class IP_O_UAV_01_backpack_FGrey						 { quality = 3; price = 150; };

//////////////////////////////////////////////////////////////////////////////////////////
// Boats
//////////////////////////////////////////////////////////////////////////////////////////
class IP_O_Boat_Armed_01_hmg_F_SnowTiger						 { quality = 3; price = 15000; };
class IP_O_Boat_Transport_01_F_SnowTiger						 { quality = 3; price = 15000; };
class IP_O_Lifeboat_SnowTiger						 { quality = 3; price = 15000; };
class IP_O_SDV_01_FST						 { quality = 3; price = 15000; };

//////////////////////////////////////////////////////////////////////////////////////////
// Cars
//////////////////////////////////////////////////////////////////////////////////////////
class IP_O_APC_Wheeled_02_rcws_FST						  { quality = 3; price = 15000; };
class IP_O_MRAP_02_FST						  { quality = 3; price = 15000; };
class IP_O_MRAP_02_gmg_FST						  { quality = 3; price = 15000; };
class IP_O_MRAP_02_hmg_FST						  { quality = 3; price = 15000; };
class IP_O_Quadbike_01_FST						  { quality = 3; price = 15000; };
class IP_O_Truck_03_ammo_FST						  { quality = 3; price = 15000; };
class IP_O_Truck_03_covered_FST						  { quality = 3; price = 15000; };
class IP_O_Truck_03_fuel_FST						  { quality = 3; price = 15000; };
class IP_O_Truck_03_medical_FST						  { quality = 3; price = 15000; };
class IP_O_Truck_03_repair_FST						  { quality = 3; price = 15000; };
class IP_O_Truck_03_transport_FST						  { quality = 3; price = 15000; };
class IP_O_UGV_01_FST						  { quality = 3; price = 15000; };
class IP_O_UGV_01_rcws_FST						  { quality = 3; price = 15000; };

//////////////////////////////////////////////////////////////////////////////////////////
// Choppers
//////////////////////////////////////////////////////////////////////////////////////////
class IP_O_Heli_Attack_02_SnowHex_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Light_02_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Light_02_unarmed_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_ammo_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_bench_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_box_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_covered_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_fuel_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_medevac_FST						 { quality = 3; price = 15000; };
class IP_O_Heli_Transport_04_repair_FST						 { quality = 3; price = 15000; };

//////////////////////////////////////////////////////////////////////////////////////////
// Planes
//////////////////////////////////////////////////////////////////////////////////////////
class IP_O_Plane_CAS_02_FRed						 { quality = 3; price = 15000; };
class IP_O_Plane_CAS_02_FSnowHex						 { quality = 3; price = 15000; };
class IP_O_UAV_02_CAS_FFST						 { quality = 3; price = 15000; };
class IP_O_UAV_02_FFST						 { quality = 3; price = 15000; };

//////////////////////////////////////////////////////////////////////////////////////////
// Tanks
//////////////////////////////////////////////////////////////////////////////////////////
class IP_O_APC_Tracked_02_AA_FST						 { quality = 3; price = 150000; };
class IP_O_APC_Tracked_02_cannon_FST						 { quality = 3; price = 150000; };
class IP_O_MBT_02_arty_FST						 { quality = 3; price = 150000; };
class IP_O_MBT_02_cannon_FST						 { quality = 3; price = 150000; };


