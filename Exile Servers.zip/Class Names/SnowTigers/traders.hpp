	
	class SnowUniforms 
	{
		name = "SnowUniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] = 
		{
			// Uniforms 
			"IP_U_O_CombatUniform_SnowTiger",
			"IP_U_O_CombatUniform_SnowHex",
			"IP_U_O_OfficerUniform_SnowTiger",
			"IP_U_O_OfficerUniform_SnowHex",
			"IP_U_O_HeliPilotCoveralls_SnowHex",
			"IP_U_O_PilotCoveralls_SnowHex",
			"IP_U_O_Wetsuit_SnowHex",
			// Headgear / Masks 
			"IP_H_Beret_02CSAT",
			"IP_H_Beret_02SnowTiger",
			"IP_H_HelmetO_SnowTiger",
			"IP_H_HelmetLeaderO_SnowTiger",
			"IP_H_HelmetO_SnowHex",
			"IP_H_HelmetLeaderO_SnowHex",
			"IP_H_HelmetSpecO_SnowTiger",
			"IP_H_HelmetSpecO_SnowHex",
			"IP_H_MilCap_HexSnow",
			"IP_H_MilCap_SnowTiger",
			"IP_H_Booniehat_HexSnow",
			"IP_H_Booniehat_SnowTiger",
			"IP_H_PilotHelmetFighter_O_Snow",
			"IP_H_PilotHelmetHeli_O_Snow",
			"IP_H_CrewHelmetHeli_O_Snow",
			"IP_H_HelmetCrew_O_Snow",
			// Vests 
			"IP_V_HarnessO_gryST",
			"IP_V_HarnessOGL_gryST",
			"IP_V_HarnessOSpec_gryST",
			"IP_V_PlateCarrierGL_rgrSnowHex",
			"IP_V_PlateCarrierGL_rgrSnowTiger",
			"IP_V_PlateCarrierSpec_rgrSnowHex",
			"IP_V_PlateCarrierSpec_rgrSnowTiger",
			"IP_V_TacVest_SnowHex",
			"IP_V_TacVest_SnowTiger",
			"IP_V_BandollierO_snw",
			"IP_V_RebreatherIR_ST",
			// Backpacks
			"IP_B_AssaultPack_SnowHex",
			"IP_B_AssaultPack_SnowTiger",
			"IP_B_Carryall_SnowHex",
			"IP_B_Carryall_SnowTiger",
			"IP_B_Carryall_AAR_SnowHex",
			"IP_B_Carryall_AAR_SnowTiger",
			"IP_B_Carryall_AAA_SnowHex",
			"IP_B_Carryall_AAA_SnowTiger",
			"IP_B_Carryall_AAT_SnowHex",
			"IP_B_Carryall_AAT_SnowTiger",
			"IP_B_Carryall_Eng_SnowHex",
			"IP_B_Carryall_Eng_SnowTiger",
			"IP_B_Carryall_Exp_SnowHex",
			"IP_B_Carryall_Exp_SnowTiger",
			"IP_B_Carryall_Ammo_SnowHex",
			"IP_B_Carryall_Ammo_SnowTiger",
			"IP_B_FieldPack_SnowHex",
			"IP_B_FieldPack_SnowTiger",
			"IP_B_FieldPack_AA_SnowHex",
			"IP_B_FieldPack_AA_SnowTiger",
			"IP_B_FieldPack_AT_SnowHex",
			"IP_B_FieldPack_AT_SnowTiger",
			"IP_B_FieldPack_LAT_SnowHex",
			"IP_B_FieldPack_LAT_SnowTiger",
			"IP_B_FieldPack_RPG_AT_SnowHex",
			"IP_B_FieldPack_RPG_AT_SnowTiger",
			"IP_B_FieldPack_Repair_SnowHex",
			"IP_B_FieldPack_Repair_SnowTiger",
			"IP_B_FieldPack_Medic_SnowHex",
			"IP_B_FieldPack_Medic_SnowTiger",
			"IP_B_FieldPack_ReconExp_SnowHex",
			"IP_B_FieldPack_ReconExp_SnowTiger",
			"IP_B_FieldPack_ReconMedic_SnowHex",
			"IP_B_FieldPack_ReconMedic_SnowTiger",
			"IP_B_Kitbag_SnowHex",
			"IP_B_Kitbag_SnowTiger",
			"IP_O_UAV_01_backpack_FGrey"
		};
	};
	
	class SnowWeapons 
	{
		name = "SnowWeapons";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] = 
		{
			// LMGs 
			"IP_MMG_01_SnowHex_F",			
			// Snipers 
			"IP_srifle_DMR_03_SnowHex_F",
			"IP_srifle_DMR_04_SnowHex_F",
			"IP_srifle_DMR_05_SnowHex_F",			
			// Launchers 
			"IP_launch_O_Titan_snw_F",
			"IP_launch_O_Titan_short_snw_F"	
		};
	};		
	
	class SnowVehicles
	{
		name = "SnowVehicles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{	
			"IP_O_APC_Wheeled_02_rcws_FST",
			"IP_O_UGV_01_FST",
			"IP_O_UGV_01_rcws_FST",
			"IP_O_Quadbike_01_FST",
			"IP_O_MRAP_02_FST",
			"IP_O_MRAP_02_gmg_FST",
			"IP_O_MRAP_02_hmg_FST",
			"IP_O_Truck_03_covered_FST",
			"IP_O_Truck_03_transport_FST",
			"IP_O_Truck_03_ammo_FST",
			"IP_O_Truck_03_fuel_FST",
			"IP_O_Truck_03_medical_FST",
			"IP_O_Truck_03_repair_FST"
		};
	};

	class SnowChoppers
	{
		name = "SnowChoppers";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"IP_O_Heli_Light_02_FST",
			"IP_O_Heli_Light_02_unarmed_FST",
			"IP_O_Heli_Transport_04_ammo_FST",
			"IP_O_Heli_Transport_04_bench_FST",
			"IP_O_Heli_Transport_04_box_FST",
			"IP_O_Heli_Transport_04_covered_FST",
			"IP_O_Heli_Transport_04_FST",
			"IP_O_Heli_Transport_04_fuel_FST",
			"IP_O_Heli_Transport_04_medevac_FST",
			"IP_O_Heli_Transport_04_repair_FST",
			"IP_O_Heli_Attack_02_SnowHex_FST"
		};
	};
	
	class SnowPlanes
	{
		name = "SnowPlanes";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"IP_O_Plane_CAS_02_FRed",
			"IP_O_Plane_CAS_02_FSnowHex",
			"IP_O_UAV_02_FFST",
			"IP_O_UAV_02_CAS_FFST"
		};
	};
	
	class SnowBoats
	{
		name = "SnowBoats";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"IP_O_Lifeboat_SnowTiger",
			"IP_O_Boat_Transport_01_F_SnowTiger",
			"IP_O_Boat_Armed_01_hmg_F_SnowTiger",
			"IP_O_SDV_01_FST"
		};
	};
	
	class SnowTanks
	{
		name = "SnowTanks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"IP_O_APC_Tracked_02_AA_FST",
			"IP_O_APC_Tracked_02_cannon_FST",
			"IP_O_MBT_02_cannon_FST",
			"IP_O_MBT_02_arty_FST"
		};
	};
	
