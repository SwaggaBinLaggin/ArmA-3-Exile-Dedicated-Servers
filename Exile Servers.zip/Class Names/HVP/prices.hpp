		///////////////////////////////////////////////////////////////////////////////
		// HVP Stuff
		///////////////////////////////////////////////////////////////////////////////
		
		///////////////////////////////////////////////////////////////////////////////
		// yamaha R6 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mrshounka_yamaha_p_bf 			{ quality = 1; price = 4000; }; 
		class Mrshounka_yamaha_p_g 				{ quality = 1; price = 4000; }; 
		class Mrshounka_yamaha_p_j 				{ quality = 1; price = 4000; }; 
		class Mrshounka_yamaha_p_noir 			{ quality = 1; price = 4000; }; 
		class Mrshounka_yamaha_p_o 				{ quality = 1; price = 4000; }; 
		class Mrshounka_yamaha_p_rose		 	{ quality = 1; price = 4000; }; 
		class Mrshounka_yamaha_p_r 				{ quality = 1; price = 4000; }; 
		class Mrshounka_yamaha_p_v 				{ quality = 1; price = 4000; }; 
		
		/////////////////////////////////////////////////////////////////////////////// 
		// pugeot 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mrshounka_a3_308_civ_bleufonce 	{ quality = 1; price = 7000; }; 
		class Mrshounka_a3_308_civ_grise 		{ quality = 1; price = 7000; };
		class Mrshounka_a3_308_civ_jaune 		{ quality = 1; price = 7000; };
		class Mrshounka_a3_308_civ_noir 		{ quality = 1; price = 7000; };
		class Mrshounka_a3_308_civ_orange 		{ quality = 1; price = 7000; };
		class Mrshounka_a3_308_civ_rose 		{ quality = 1; price = 7000; };
		class Mrshounka_a3_308_civ_rouge 		{ quality = 1; price = 7000; }; 
		class Mrshounka_a3_308_civ_violet 		{ quality = 1; price = 7000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// buggy 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class shounka_buggy_bleufonce 			{ quality = 1; price = 8000; }; 
		class shounka_buggy_grise 				{ quality = 1; price = 8000; }; 
		class shounka_buggy_jaune 				{ quality = 1; price = 8000; }; 
		class shounka_buggy_noir 				{ quality = 1; price = 8000; }; 
		class shounka_buggy_orange 				{ quality = 1; price = 8000; }; 
		class shounka_buggy_rose 				{ quality = 1; price = 8000; }; 
		class shounka_buggy_rouge 				{ quality = 1; price = 8000; }; 
		class shounka_buggy_violet 				{ quality = 1; price = 8000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// GMC van
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mrshounka_Vandura_civ 			{ quality = 1; price = 9000; }; 
		class Mrshounka_Vandura_civ_bleufonce 	{ quality = 1; price = 9000; }; 
		class Mrshounka_Vandura_civ_grise 		{ quality = 1; price = 9000; };
		class Mrshounka_Vandura_civ_jaune 		{ quality = 1; price = 9000; }; 
		class Mrshounka_Vandura_civ_noir  		{ quality = 1; price = 9000; };
		class Mrshounka_Vandura_civ_orange		{ quality = 1; price = 9000; };
		class Mrshounka_Vandura_civ_rose  		{ quality = 1; price = 9000; }; 
		class Mrshounka_Vandura_civ_rouge 		{ quality = 1; price = 9000; }; 
		class Mrshounka_Vandura_civ_violet		{ quality = 1; price = 9000; }; 
		
		/////////////////////////////////////////////////////////////////////////////// 
		// hummer 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mr_Own_hummer_civ_noir 			{ quality = 1; price = 10000; }; 
		class Mr_Own_hummer_civ_bleufonce 		{ quality = 1; price = 10000; }; 
		class Mr_Own_hummer_civ_grise 			{ quality = 1; price = 10000; }; 
		class Mr_Own_hummer_civ_jaune 			{ quality = 1; price = 10000; }; 
		class Mr_Own_hummer_civ_orange 			{ quality = 1; price = 10000; }; 
		class Mr_Own_hummer_civ_rose 			{ quality = 1; price = 10000; }; 
		class Mr_Own_hummer_civ_rouge 			{ quality = 1; price = 10000; }; 
		class Mr_Own_hummer_civ_violet 			{ quality = 1; price = 10000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// roadrunners 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class SIG_Roadrunner 					{ quality = 1; price = 12000; }; 
		class SIG_Hubcaps 						{ quality = 1; price = 12000; };
		class SIG_Magnums 						{ quality = 1; price = 12000; }; 
		class SIG_Hcode 						{ quality = 1; price = 12000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// avalanche
		/////////////////////////////////////////////////////////////////////////////// 
		
		class shounka_avalanche_bleufonce 		{ quality = 1; price = 15000; }; 
		class shounka_avalanche_grise 			{ quality = 1; price = 15000; }; 
		class shounka_avalanche_jaune 			{ quality = 1; price = 15000; }; 
		class shounka_avalanche_noir 			{ quality = 1; price = 15000; }; 
		class shounka_avalanche_orange 			{ quality = 1; price = 15000; };
		class shounka_avalanche_rose 			{ quality = 1; price = 15000; };
		class shounka_avalanche_rouge 			{ quality = 1; price = 15000; }; 
		class shounka_avalanche_violet 			{ quality = 1; price = 15000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// zombie car :P 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mrshounka_corbillard_c_bleufonce 	{ quality = 1; price = 16000; }; 
		class Mrshounka_corbillard_c_grise 		{ quality = 1; price = 16000; };
		class Mrshounka_corbillard_c_jaune		{ quality = 1; price = 16000; }; 
		class Mrshounka_corbillard_c_noir 		{ quality = 1; price = 16000; }; 
		class Mrshounka_corbillard_c_orange 	{ quality = 1; price = 16000; }; 
		class Mrshounka_corbillard_c_rose 		{ quality = 1; price = 16000; }; 
		class Mrshounka_corbillard_c_rouge 		{ quality = 1; price = 16000; }; 
		class Mrshounka_corbillard_c_violet 	{ quality = 1; price = 16000; }; 
		
		////////////////////////////////////////////////////////////////////////////// 
		// superbees 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class SIG_Superbee 						{ quality = 1; price = 18000; }; 
		class SIG_SuperbeeY 					{ quality = 1; price = 18000; }; 
		class SIG_SuperbeeB 					{ quality = 1; price = 18000; }; 
		class SIG_SuperbeeL 					{ quality = 1; price = 18000; }; 
		class SIG_SuperbeeM 					{ quality = 1; price = 18000; }; 
		class SIG_SuperbeeG 					{ quality = 1; price = 18000; }; 
		
		/////////////////////////////////////////////////////////////////////////////// 
		// armored buggy 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mr_Own_buggy_bleufonce 			{ quality = 1; price = 19000; }; 
		class Mr_Own_buggy_grise 				{ quality = 1; price = 19000; }; 
		class Mr_Own_buggy_jaune 				{ quality = 1; price = 19000; }; 
		class Mr_Own_buggy_noir 				{ quality = 1; price = 19000; }; 
		class Mr_Own_buggy_orange				{ quality = 1; price = 19000; }; 
		class Mr_Own_buggy_rose 				{ quality = 1; price = 19000; }; 
		class Mr_Own_buggy_rouge 				{ quality = 1; price = 19000; }; 
		class Mr_Own_buggy_violet				{ quality = 1; price = 19000; }; 
		
		/////////////////////////////////////////////////////////////////////////////// 
		// monster trucks
		/////////////////////////////////////////////////////////////////////////////// 
		
		class shounka_monsteur_bleufonce 		{ quality = 1; price = 25000; }; 
		class shounka_monsteur_grise 			{ quality = 1; price = 25000; }; 
		class shounka_monsteur_jaune 			{ quality = 1; price = 25000; }; 
		class shounka_monsteur_noir  			{ quality = 1; price = 25000; }; 
		class shounka_monsteur_orange			{ quality = 1; price = 25000; };
		class shounka_monsteur_rose  			{ quality = 1; price = 25000; }; 
		class shounka_monsteur_rouge 			{ quality = 1; price = 25000; }; 
		class shounka_monsteur_violet			{ quality = 1; price = 25000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// Truck(Trailerless)
		/////////////////////////////////////////////////////////////////////////////// 
		
		class shounka_a3_dafxf_euro6_f 			{ quality = 1; price = 28000; }; 
		
		/////////////////////////////////////////////////////////////////////////////// 
		// Truck(Trailer)
		/////////////////////////////////////////////////////////////////////////////// 
		
		class shounka_ivceco_bleufonce 			{ quality = 1; price = 29000; }; 
		class shounka_ivceco_grise 				{ quality = 1; price = 29000; }; 
		class shounka_ivceco_jaune 				{ quality = 1; price = 29000; }; 
		class shounka_ivceco_noir  				{ quality = 1; price = 29000; }; 
		class shounka_ivceco_orange				{ quality = 1; price = 29000; }; 
		class shounka_ivceco_rose  				{ quality = 1; price = 29000; }; 
		class shounka_ivceco_rouge 				{ quality = 1; price = 29000; };
		class shounka_ivceco_violet				{ quality = 1; price = 29000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// Limo 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class shounka_limo_civ_bleufonce 		{ quality = 1; price = 30000; }; 
		class shounka_limo_civ_grise 			{ quality = 1; price = 30000; }; 
		class shounka_limo_civ_jaune 			{ quality = 1; price = 30000; }; 
		class shounka_limo_civ_noir  			{ quality = 1; price = 30000; };
		class shounka_limo_civ_orange			{ quality = 1; price = 30000; }; 
		class shounka_limo_civ_rose  			{ quality = 1; price = 30000; }; 
		class shounka_limo_civ_violet			{ quality = 1; price = 30000; }; 
		
		/////////////////////////////////////////////////////////////////////////////// 
		// dodge charger 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mr_Own_dodge15_civ 				{ quality = 1; price = 32000; }; 
		class Mr_Own_dodge15_civ_bleufonce 		{ quality = 1; price = 32000; }; 
		class Mr_Own_dodge15_civ_grise 			{ quality = 1; price = 32000; }; 
		class Mr_Own_dodge15_civ_jaune 			{ quality = 1; price = 32000; }; 
		class Mr_Own_dodge15_civ_noir 			{ quality = 1; price = 32000; }; 
		class Mr_Own_dodge15_civ_orange 		{ quality = 1; price = 32000; };
		class Mr_Own_dodge15_civ_rose 			{ quality = 1; price = 32000; }; 
		class Mr_Own_dodge15_civ_rouge 			{ quality = 1; price = 32000; };
		class Mr_Own_dodge15_civ_violet 		{ quality = 1; price = 32000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// Ferrari 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class shounka_f430_spider_bleufonce 	{ quality = 1; price = 35000; };
		class shounka_f430_spider_grise 		{ quality = 1; price = 35000; }; 
		class shounka_f430_spider_jaune 		{ quality = 1; price = 35000; }; 
		class shounka_f430_spider_noir 			{ quality = 1; price = 35000; }; 
		class shounka_f430_spider_rose 			{ quality = 1; price = 35000; }; 
		class shounka_f430_spider_rouge 		{ quality = 1; price = 35000; }; 
		class shounka_f430_spider_violet 		{ quality = 1; price = 35000; };
		
		/////////////////////////////////////////////////////////////////////////////// 
		// Lykan 
		/////////////////////////////////////////////////////////////////////////////// 
		
		class Mrshounka_lykan_c_bleufonce 		{ quality = 1; price = 36000; }; 
		class Mrshounka_lykan_c_grise 			{ quality = 1; price = 36000; };
		class Mrshounka_lykan_c_jaune 			{ quality = 1; price = 36000; }; 
		class Mrshounka_lykan_c_noir 			{ quality = 1; price = 36000; }; 
		class Mrshounka_lykan_c_orange 			{ quality = 1; price = 36000; }; 
		class Mrshounka_lykan_c_rose 			{ quality = 1; price = 36000; }; 
		class Mrshounka_lykan_c_rouge 			{ quality = 1; price = 36000; }; 
		class Mrshounka_lykan_c_violet 			{ quality = 1; price = 36000; }; 
		
		/////////////////////////////////////////////////////////////////////////////// 
		// planes
		/////////////////////////////////////////////////////////////////////////////// 
		
		class sab_camel_blu 					{ quality = 1; price = 28000; }; 
		class sab_camel_red 					{ quality = 1; price = 28000; }; 
