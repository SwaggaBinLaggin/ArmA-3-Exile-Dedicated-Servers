	class MASUniforms
	{
		name = "MASUniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] = 
		{
			"U_mas_sfod_B_CombatUniform_wood", 
			"U_mas_sfod_B_CombatUniform_wood_tshirt", 
			"U_mas_sfod_B_CombatUniform_wood_vest", 
			"U_mas_sfod_B_CombatUniform_wood_vest1", 
			"U_mas_sfod_B_CombatUniform_wood_vest2", 
			"U_mas_sfod_B_CombatUniform_wood_vest3", 
			"U_mas_sfod_B_CombatUniform_wood_vest4", 
			"U_mas_sfod_B_CombatUniform_des", 
			"U_mas_sfod_B_CombatUniform_des_tshirt", 
			"U_mas_sfod_B_CombatUniform_des_vest", 
			"U_mas_sfod_B_CombatUniform_des_vest1", 
			"U_mas_sfod_B_CombatUniform_des_vest2", 
			"U_mas_usn_B_CombatUniform_mcam", 
			"U_mas_usn_B_CombatUniform_mcam_tshirt", 
			"U_mas_usn_B_CombatUniform_mcam_vest", 
			"U_mas_usn_B_CombatUniform_mcam_vest1", 
			"U_mas_usn_B_CombatUniform_mcam_vest2", 
			"U_mas_usn_B_CombatUniform_mcam_vest3", 
			"U_mas_usn_B_CombatUniform_mcam_vest4", 
			"U_mas_usn_B_CombatUniform_veg", 
			"U_mas_usn_B_CombatUniform_veg_tshirt", 
			"U_mas_usn_B_CombatUniform_veg_vest", 
			"U_mas_usn_B_CombatUniform_veg_vest1", 
			"U_mas_usn_B_CombatUniform_veg_vest2", 
			"U_mas_usn_B_CombatUniform_des", 
			"U_mas_usn_B_CombatUniform_des_tshirt", 
			"U_mas_usn_B_CombatUniform_des_vest", 
			"U_mas_usn_B_CombatUniform_des_vest1", 
			"U_mas_usn_B_CombatUniform_des_vest2", 
			"U_mas_usn_B_CombatUniform_sage", 
			"U_mas_usn_B_CombatUniform_sage_tshirt", 
			"U_mas_usn_B_CombatUniform_sage_vest", 
			"U_mas_usn_B_CombatUniform_wood", 
			"U_mas_usn_B_CombatUniform_wood_tshirt", 
			"U_mas_usn_B_CombatUniform_wood_vest", 
			"U_mas_usd_B_CombatUniform_mcam", 
			"U_mas_usd_B_CombatUniform_mcam_tshirt", 
			"U_mas_usd_B_CombatUniform_mcam_vest", 
			"U_mas_usd_B_CombatUniform_mcam_vest1", 
			"U_mas_usr_B_IndUniform1_o", 
			"U_mas_usr_B_IndUniform2_o", 
			"U_mas_usr_B_IndUniform1_v", 
			"U_mas_usr_B_IndUniform2_v", 
			"U_mas_usr_B_IndUniform1_d", 
			"U_mas_usr_B_IndUniform2_d", 
			"U_mas_usd_B_founiform1_o", 
			"U_mas_usd_B_founiform2_o", 
			"U_mas_usd_B_founiform3_o", 
			"U_mas_usd_B_founiform4_o", 
			"U_mas_usd_B_founiform5_o", 
			"U_mas_usd_B_founiform6_o", 
			"U_mas_usd_B_founiform7_o", 
			"U_mas_usd_B_founiform8_o", 
			"U_mas_usd_B_founiform9_o", 
			"U_mas_usn_B_DEV", 
			"U_mas_usn_B_wint", 
			"U_mas_usn_B_pilot", 
			"U_mas_usn_B_Wetsuit", 
			"U_mas_usn_B_GhillieSuit", 
			"U_mas_usn_B_GhillieSuit_v", 
			"U_mas_usn_B_GhillieSuit_d", 
			"U_mas_usn_B_GhillieSuit_w"
		};
	};

	class MASVests
	{
		name = "MASVests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] = 
		{
			"V_mas_usn_Rangemaster_belt", 
			"V_mas_usn_BandollierB_rgr", 
			"V_mas_usn_PlateCarrier1_rgr", 
			"V_mas_usn_PlateCarrier2_rgr", 
			"V_mas_usn_PlateCarrierGL_rgr", 
			"V_mas_usn_ChestrigB_rgr", 
			"V_mas_usr_BandollierB_rgr_m", 
			"V_mas_usr_PlateCarrier1_rgr_m", 
			"V_mas_usr_PlateCarrier2_rgr_m", 
			"V_mas_usn_Rangemaster_belt_d", 
			"V_mas_usn_BandollierB_rgr_d", 
			"V_mas_usn_PlateCarrier1_rgr_d", 
			"V_mas_usn_PlateCarrier2_rgr_d", 
			"V_mas_usn_PlateCarrierGL_rgr_d", 
			"V_mas_usn_ChestrigB_rgr_d", 
			"V_mas_usn_Rangemaster_belt_v", 
			"V_mas_usn_BandollierB_rgr_v", 
			"V_mas_usn_PlateCarrier1_rgr_v", 
			"V_mas_usn_PlateCarrier2_rgr_v", 
			"V_mas_usn_PlateCarrierGL_rgr_v", 
			"V_mas_usn_ChestrigB_rgr_v", 
			"V_mas_usn_Rangemaster_belt_g", 
			"V_mas_usn_BandollierB_rgr_g", 
			"V_mas_usn_PlateCarrier1_rgr_g", 
			"V_mas_usn_PlateCarrier2_rgr_g", 
			"V_mas_usn_PlateCarrierGL_rgr_g", 
			"V_mas_usn_ChestrigB_rgr_g", 
			"V_mas_usn_PlateCarrier1_rgr_w", 
			"V_mas_usn_ChestrigB_rgr_w", 
			"V_mas_usr_Rangemaster_belt", 
			"V_mas_usr_BandollierB_rgr", 
			"V_mas_usr_PlateCarrier1_rgr", 
			"V_mas_usr_PlateCarrier2_rgr", 
			"V_mas_usr_PlateCarrierGL_rgr", 
			"V_mas_usr_ChestrigB_rgr", 
			"V_mas_usr_Rangemaster_belt_d", 
			"V_mas_usr_BandollierB_rgr_d", 
			"V_mas_usr_PlateCarrier1_rgr_d", 
			"V_mas_usr_PlateCarrier2_rgr_d", 
			"V_mas_usr_PlateCarrierGL_rgr_d", 
			"V_mas_usr_ChestrigB_rgr_d", 
			"V_mas_usr_Rangemaster_belt_g", 
			"V_mas_usr_BandollierB_rgr_g", 
			"V_mas_usr_PlateCarrier1_rgr_g", 
			"V_mas_usr_PlateCarrier2_rgr_g", 
			"V_mas_usr_PlateCarrierGL_rgr_g", 
			"V_mas_usr_ChestrigB_rgr_g", 
			"V_mas_usn_TacVest_p", 
			"V_mas_usn_TacVest_g"
		};
	};

	class MASHeadgear 
	{
		name = "MASHeadgear";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
			"H_mas_usn_PilotHelmetHeli_B", 
			"H_mas_usn_CrewHelmetHeli_B", 
			"H_mas_usn_CrewHelmet_B", 
			"H_mas_usn_off", 
			"H_mas_usn_off_v", 
			"H_mas_usn_off_d", 
			"H_mas_usn_off_g", 
			"H_mas_usr_off", 
			"H_mas_usr_off_v", 
			"H_mas_usr_off_d", 
			"H_mas_usr_off_g", 
			"H_mas_usr_beret", 
			"H_mas_sfod_beret", 
			"H_mas_usn_MilCap_mcamo", 
			"H_mas_usn_MilCap_mcamo_v", 
			"H_mas_usn_MilCap_mcamo_d", 
			"H_mas_usn_Cap", 
			"H_mas_usn_Cap_headphones", 
			"H_mas_usn_Cap_headphones_d", 
			"H_mas_usn_Cap_headphones_v", 
			"H_mas_usn_Cap_headphones_w", 
			"H_mas_usn_Cap_headphones_g", 
			"H_mas_usn_Woolhat", 
			"H_mas_usn_Woolhat_c", 
			"H_mas_usn_Woolhat_w", 
			"H_mas_usn_woolhat_ht", 
			"H_mas_usn_woolhat_ht_w", 
			"H_mas_usn_Booniehat_mul", 
			"H_mas_usd_Booniehat_mul", 
			"H_mas_usd_Booniehat_tan", 
			"H_mas_usn_Booniehat_rgr", 
			"H_mas_usn_Booniehat_des", 
			"H_mas_usr_Booniehat_rgr", 
			"H_mas_usr_Booniehat_des", 
			"H_mas_usn_revcapheadset_b", 
			"H_mas_usn_revcapheadset_v", 
			"H_mas_usn_bandana", 
			"H_mas_usn_bandana_ht", 
			"H_mas_usn_helmet_mich_sf", 
			"H_mas_usn_helmet_mich_sf_g", 
			"H_mas_usn_helmet_mich_sf_m", 
			"H_mas_usn_helmet_mich_sf_w", 
			"H_mas_usn_helmet_mich_sf_b", 
			"H_mas_usn_helmet_mich_sf_gog", 
			"H_mas_usn_helmet_mich_sf_gog_g", 
			"H_mas_usn_helmet_mich_sf_gog_m", 
			"H_mas_usn_helmet_mich_sf_gog_w", 
			"H_mas_usn_helmet_mich_sf_gog_b", 
			"H_mas_usn_helmet_mich_sf_h", 
			"H_mas_usn_helmet_mich_sf_h_g", 
			"H_mas_usn_helmet_mich_sf_h_m",  
			"H_mas_usn_helmet_mich_sf_h_w", 
			"H_mas_usn_helmet_mich_sf_h_b", 
			"H_mas_usn_helmet_ops_sf", 
			"H_mas_usn_helmet_ops_sf_b", 
			"H_mas_usn_helmet_ops_sf_g", 
			"H_mas_usn_helmet_ops_sf_d", 
			"H_mas_usn_helmet_ops_sf_w", 
			"H_mas_usn_helmet_ops_sf_e", 
			"H_mas_usn_helmet_ops_sf_v", 
			"H_mas_usn_helmet_ops_sf_m", 
			"H_mas_usn_helmet_ops_sf_z", 
			"H_mas_usn_helmet_ops_sf_gog", 
			"H_mas_usn_helmet_ops_sf_gog_b", 
			"H_mas_usn_helmet_ops_sf_gog_g", 
			"H_mas_usn_helmet_ops_sf_gog_d", 
			"H_mas_usn_helmet_ops_sf_gog_w", 
			"H_mas_usn_helmet_ops_sf_gog_e", 
			"H_mas_usn_helmet_ops_sf_gog_v", 
			"H_mas_usn_helmet_ops_sf_gog_m", 
			"H_mas_usn_helmet_ops_sf_gog_z", 
			"H_mas_usn_helmet_ops_sf_h", 
			"H_mas_usn_helmet_ops_sf_h_b", 
			"H_mas_usn_helmet_ops_sf_h_g", 
			"H_mas_usn_helmet_ops_sf_h_d", 
			"H_mas_usn_helmet_ops_sf_h_w", 
			"H_mas_usn_helmet_ops_sf_h_e", 
			"H_mas_usn_helmet_ops_sf_h_v", 
			"H_mas_usn_helmet_ops_sf_h_m", 
			"H_mas_usn_helmet_ops_sf_h_z",
			"G_mas_wpn_gog", 
			"G_mas_wpn_gog_d", 
			"G_mas_wpn_gog_m", 
			"G_mas_wpn_gog_md", 
			"G_mas_wpn_gog_g", 
			"G_mas_wpn_gog_gd", 
			"G_mas_wpn_mask", 
			"G_mas_wpn_mask_b", 
			"G_mas_wpn_wrap", 
			"G_mas_wpn_wrap_f", 
			"G_mas_wpn_wrap_t", 
			"G_mas_wpn_wrap_b", 
			"G_mas_wpn_wrap_c", 
			"G_mas_wpn_wrap_g", 
			"G_mas_wpn_wrap_gog", 
			"G_mas_wpn_wrap_gog_f", 
			"G_mas_wpn_wrap_gog_t", 
			"G_mas_wpn_wrap_gog_b", 
			"G_mas_wpn_wrap_gog_c", 
			"G_mas_wpn_wrap_gog_g", 
			"G_mas_wpn_wrap_mask", 
			"G_mas_wpn_wrap_mask_t", 
			"G_mas_wpn_wrap_mask_f", 
			"G_mas_wpn_wrap_mask_b", 
			"G_mas_wpn_wrap_mask_c", 
			"G_mas_wpn_wrap_mask_g", 
			"G_mas_wpn_bala", 
			"G_mas_wpn_bala_b", 
			"G_mas_wpn_bala_t", 
			"G_mas_wpn_bala_gog", 
			"G_mas_wpn_bala_gog_b", 
			"G_mas_wpn_bala_gog_t", 
			"G_mas_wpn_bala_mask", 
			"G_mas_wpn_bala_mask_b", 
			"G_mas_wpn_bala_mask_t", 
			"G_mas_wpn_shemag", 
			"G_mas_wpn_shemag_r", 
			"G_mas_wpn_shemag_w", 
			"G_mas_wpn_shemag_gog", 
			"G_mas_wpn_shemag_mask"
		};
	};

	class MASPointerAttachments 
	{
		name = "MASPointerAttachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"acc_mas_flash_gun",
			"acc_mas_pointer_gun_IR", 
			"acc_mas_pointer_IR", 
			"acc_mas_pointer_IR_b", 
			"acc_mas_pointer_IR_top", 
			"acc_mas_pointer_IR_top_b", 
			"acc_mas_pointer_IR2", 
			"acc_mas_pointer_IR2_top", 
			"acc_mas_pointer_IR2c", 
			"acc_mas_pointer_IR2c_top"
		};
	};

	class MASMuzzleAttachments 
	{
		name = "MASMuzzleAttachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] = 
		{
			"muzzle_mas_snds_L", 
			"muzzle_mas_snds_LM", 
			"muzzle_mas_snds_C", 
			"muzzle_mas_snds_MP5SD6", 
			"muzzle_mas_snds_M", 
			"muzzle_mas_snds_Mc", 
			"muzzle_mas_snds_MP7", 
			"muzzle_mas_snds_AK", 
			"muzzle_mas_snds_SM", 
			"muzzle_mas_snds_SMc", 
			"muzzle_mas_snds_SH", 
			"muzzle_mas_snds_SHc", 
			"muzzle_mas_snds_SV", 
			"muzzle_mas_snds_SVc", 
			"muzzle_mas_snds_SVD", 
			"muzzle_mas_snds_KSVK"
		};
	};
	
	class MASOpticAttachments 
	{
		name = "MASOpticAttachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
			"optic_mas_DMS",
			"optic_mas_DMS_c", 
			"optic_mas_Holosight_blk", 
			"optic_mas_Holosight_camo", 
			"optic_mas_Arco_blk", 
			"optic_mas_Arco_camo", 
			"optic_mas_Hamr_camo", 
			"optic_mas_Aco_camo", 
			"optic_mas_ACO_grn_camo", 
			"optic_mas_MRCO_camo", 
			"optic_mas_zeiss", 
			"optic_mas_zeiss_c", 
			"optic_mas_zeiss_eo", 
			"optic_mas_zeiss_eo_c", 
			"optic_mas_acog", 
			"optic_mas_acog_c", 
			"optic_mas_acog_eo", 
			"optic_mas_acog_eo_c", 
			"optic_mas_acog_rd", 
			"optic_mas_acog_rd_c", 
			"optic_mas_handle", 
			"optic_mas_aim", 
			"optic_mas_aim_c", 
			"optic_mas_PSO", 
			"optic_mas_PSO_c", 
			"optic_mas_PSO_eo", 
			"optic_mas_PSO_eo_c", 
			"optic_mas_PSO_nv", 
			"optic_mas_PSO_nv_c", 
			"optic_mas_PSO_nv_eo", 
			"optic_mas_PSO_nv_eo_c", 
			"optic_mas_PSO_day", 
			"optic_mas_PSO_nv_day", 
			"optic_mas_term", 
			"optic_mas_MRD", 
			"optic_mas_LRPS", 
			"optic_mas_kobra", 
			"optic_mas_kobra_c", 
			"optic_mas_nspu", 
			"optic_mas_goshawk", 
			"optic_mas_PSO_kv", 
			"optic_mas_PSO_kv_c"
		};
	};

	class MASBackpacks
	{
		name = "MASBackpacks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			"B_mas_m_Bergen_us",
			"B_mas_m_Bergen_us_g",
			"B_mas_m_Bergen_us_m",
			"B_mas_m_Bergen_us_b",
			"B_mas_m_Bergen_us_w",
			"B_mas_m_Bergen_acr",
			"B_mas_m_Bergen_acr_c",
			"B_mas_m_Bergen_acr_g",
			"B_mas_m_Bergen_acr_w", 
			"B_mas_m_Bergen_rpg",  
			"B_mas_m_Bergen_rpg_b", 
			"B_mas_m_Bergen_al", 
			"B_mas_AssaultPack_mul", 
			"B_mas_Kitbag_mul", 
			"B_mas_Bergen_mul", 
			"B_mas_AssaultPack_mul_ammo", 
			"B_mas_AssaultPack_mul_ammo_MG", 
			"B_mas_AssaultPack_mul_Medic", 
			"B_mas_AssaultPack_mul_AA", 
			"B_mas_AssaultPack_mul_AT", 
			"B_mas_AssaultPack_mul_AT4", 
			"B_mas_AssaultPack_mul_m72", 
			"B_mas_AssaultPack_mul_MAAWS", 
			"B_mas_AssaultPack_mul_SMAW", 
			"B_mas_AssaultPack_mul_ATM", 
			"B_mas_AssaultPack_mul_Repair", 
			"B_mas_Bergen_mul_Exp", 
			"B_mas_AssaultPack_des", 
			"B_mas_Kitbag_des", 
			"B_mas_Bergen_des", 
			"B_mas_AssaultPack_des_Medic",
			"B_mas_AssaultPack_des_AA", 
			"B_mas_AssaultPack_des_AT", 
			"B_mas_AssaultPack_des_AT4", 
			"B_mas_AssaultPack_des_m72", 
			"B_mas_AssaultPack_des_MAAWS", 
			"B_mas_AssaultPack_des_SMAW", 
			"B_mas_AssaultPack_des_ATM", 
			"B_mas_AssaultPack_des_Repair", 
			"B_mas_Bergen_des_Exp", 
			"B_mas_AssaultPack_black", 
			"B_mas_Kitbag_black", 
			"B_mas_Bergen_black", 
			"B_mas_AssaultPack_black_Medic", 
			"B_mas_AssaultPack_black_AA", 
			"B_mas_AssaultPack_black_AT", 
			"B_mas_AssaultPack_black_AT4",
			"B_mas_AssaultPack_black_m72",
			"B_mas_AssaultPack_black_MAAWS", 
			"B_mas_AssaultPack_black_SMAW", 
			"B_mas_AssaultPack_black_ATM", 
			"B_mas_AssaultPack_black_Repair",
			"B_mas_Bergen_black_Exp",
			"B_mas_AssaultPack_rng", 
			"B_mas_Kitbag_rng", 
			"B_mas_Bergen_rng", 
			"B_mas_AssaultPack_rng_Medic", 
			"B_mas_AssaultPack_rng_AA", 
			"B_mas_AssaultPack_rng_AT", 
			"B_mas_AssaultPack_rng_AT4", 
			"B_mas_AssaultPack_rng_m72", 
			"B_mas_AssaultPack_rng_MAAWS", 
			"B_mas_AssaultPack_rng_SMAW", 
			"B_mas_AssaultPack_rng_ATM", 
			"B_mas_AssaultPack_rng_Repair", 
			"B_mas_Bergen_rng_Exp"
		};
	};

	class MASAmmunition
	{
		name = "MASAmmunition";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"30Rnd_mas_556x45_Stanag",
			"30Rnd_mas_556x45_T_Stanag",
			"200Rnd_mas_556x45_Stanag", 
			"200Rnd_mas_556x45_T_Stanag", 
			"100Rnd_mas_762x51_Stanag", 
			"100Rnd_mas_762x51_T_Stanag", 
			"100Rnd_mas_762x54_mag", 
			"100Rnd_mas_762x54_T_mag", 
			"100Rnd_mas_762x39_mag",
			"100Rnd_mas_762x39_T_mag", 
			"30Rnd_mas_545x39_mag", 
			"30Rnd_mas_545x39_T_mag", 
			"100Rnd_mas_545x39_mag", 
			"100Rnd_mas_545x39_T_mag", 
			"20Rnd_mas_762x51_Stanag",
			"20Rnd_mas_762x51_T_Stanag", 
			"5Rnd_mas_762x51_Stanag", 
			"5Rnd_mas_762x51_T_Stanag", 
			"10Rnd_mas_338_Stanag", 
			"10Rnd_mas_338_T_Stanag", 
			"30Rnd_mas_762x39_mag", 
			"30Rnd_mas_762x39_T_mag", 
			"10Rnd_mas_762x54_mag", 
			"10Rnd_mas_762x54_T_mag", 
			"5Rnd_mas_127x99_Stanag", 
			"5Rnd_mas_127x99_dem_Stanag", 
			"5Rnd_mas_127x99_T_Stanag", 
			"5Rnd_mas_127x108_mag", 
			"5Rnd_mas_127x108_dem_mag", 
			"5Rnd_mas_127x108_T_mag", 
			"30Rnd_mas_9x21_Stanag", 
			"30Rnd_mas_9x21d_Stanag", 
			"12Rnd_mas_45acp_Mag", 
			"10Rnd_mas_45acp_Mag", 
			"8Rnd_mas_45acp_Mag", 
			"15Rnd_mas_9x21_Mag", 
			"17Rnd_mas_9x21_Mag", 
			"13Rnd_mas_9x21_Mag", 
			"8Rnd_mas_9x18_mag", 
			"64Rnd_mas_9x18_mag", 
			"20Rnd_mas_765x17_Mag", 
			"25Rnd_mas_9x19_Mag", 
			"40Rnd_mas_46x30_Mag", 
			"150Rnd_mas_556x45_Stanag", 
			"150Rnd_mas_556x45_T_Stanag",
			"30Rnd_mas_556x45sd_Stanag",
			"30Rnd_mas_545x39sd_mag",
			"20Rnd_mas_762x51sd_Stanag",
			"30Rnd_mas_762x39sd_mag",
			"30Rnd_mas_9x21sd_Stanag",
			"30Rnd_mas_9x39sd_mag",
			"40Rnd_mas_46x30sd_Mag"
		};
	};	

	class MASPistols 
	{
		name = "MASPistols";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
		items[] = 
		{
			"hgun_mas_m9_F",
			"hgun_mas_glock_F",
			"hgun_mas_p226_F",
			"hgun_mas_bhp_F",
			"hgun_mas_m9_F_sd",
			"hgun_mas_bhp_F_sd",
			"hgun_mas_glock_F_sd",
			"hgun_mas_p226_F_sd",
			"hgun_mas_grach_F",
			"hgun_mas_mak_F_sd",
			"hgun_mas_acp_F",
			"hgun_mas_acp_F_sd",
			"hgun_mas_usp_F", 
			"hgun_mas_usp_l_F", 
			"hgun_mas_glocksf_F", 
			"hgun_mas_glocksf_F_sd", 
			"hgun_mas_usp_F_sd", 
			"hgun_mas_usp_l_F_sd"	
		};
	};

	class MASSubMachineGuns 
	{
		name = "MASSubMachineGuns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"hgun_mas_mp7_F_sd",
			"hgun_mas_mp7p_F_sd",
			"hgun_mas_uzi_F"
		};
	};

	class MASLightMachineGuns 
	{
		name = "MASLightMachineGuns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"LMG_mas_Mk200_F_a",
			"LMG_mas_Mk200_F_sd",
			"LMG_mas_M249_F_a",
			"LMG_mas_M249_F_sd",
			"LMG_mas_M249_F_v_a",
			"LMG_mas_M249_F_v_sd",
			"LMG_mas_M249_F_d_a",
			"LMG_mas_M249_F_d_sd",
			"LMG_mas_Mk48_F_a",
			"LMG_mas_Mk48_F_v",
			"LMG_mas_Mk48_F_v_a",
			"LMG_mas_Mk48_F_d",
			"LMG_mas_Mk48_F_d_a",
			"LMG_mas_M240_F_a",
			"LMG_mas_M60_F",
			"LMG_mas_M60_F_a",
			"LMG_mas_rpk_F",
			"LMG_mas_pkm_F"
		};
	};

	class MASAssaultRifles
	{
		name = "MASAssaultRifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{,
			"arifle_mas_hk416", 
			"arifle_mas_hk416_t", 
			"arifle_mas_hk416_h", 
			"arifle_mas_hk416_a", 
			"arifle_mas_hk416_e", 
			"arifle_mas_hk416_sd", 
			"arifle_mas_hk416_gl", 
			"arifle_mas_hk416_gl_t", 
			"arifle_mas_hk416_gl_h", 
			"arifle_mas_hk416_gl_a", 
			"arifle_mas_hk416_gl_e", 
			"arifle_mas_hk416_gl_sd", 
			"arifle_mas_hk416_m203", 
			"arifle_mas_hk416_m203_t", 
			"arifle_mas_hk416_m203_h", 
			"arifle_mas_hk416_m203_a", 
			"arifle_mas_hk416_m203_e", 
			"arifle_mas_hk416_m203_sd", 
			"arifle_mas_hk416_v", 
			"arifle_mas_hk416_v_t", 
			"arifle_mas_hk416_v_h", 
			"arifle_mas_hk416_v_a", 
			"arifle_mas_hk416_v_e", 
			"arifle_mas_hk416_v_sd", 
			"arifle_mas_hk416_gl_v", 
			"arifle_mas_hk416_gl_v_t", 
			"arifle_mas_hk416_gl_v_h", 
			"arifle_mas_hk416_gl_v_a", 
			"arifle_mas_hk416_gl_v_e", 
			"arifle_mas_hk416_gl_v_sd", 
			"arifle_mas_hk416_m203_v", 
			"arifle_mas_hk416_m203_v_t", 
			"arifle_mas_hk416_m203_v_h", 
			"arifle_mas_hk416_m203_v_a", 
			"arifle_mas_hk416_m203_v_e", 
			"arifle_mas_hk416_m203_v_sd", 
			"arifle_mas_hk416_d", 
			"arifle_mas_hk416_d_t", 
			"arifle_mas_hk416_d_h", 
			"arifle_mas_hk416_d_a", 
			"arifle_mas_hk416_d_e", 
			"arifle_mas_hk416_d_sd", 
			"arifle_mas_hk416_gl_d", 
			"arifle_mas_hk416_gl_d_t", 
			"arifle_mas_hk416_gl_d_h", 
			"arifle_mas_hk416_gl_d_a", 
			"arifle_mas_hk416_gl_d_e", 
			"arifle_mas_hk416_gl_d_sd", 
			"arifle_mas_hk416_m203_d", 
			"arifle_mas_hk416_m203_d_t", 
			"arifle_mas_hk416_m203_d_h", 
			"arifle_mas_hk416_m203_d_a", 
			"arifle_mas_hk416_m203_d_e", 
			"arifle_mas_hk416_m203_d_sd", 
			"arifle_mas_hk416c", 
			"arifle_mas_hk416c_h", 
			"arifle_mas_hk416c_e", 
			"arifle_mas_hk416c_sd", 
			"arifle_mas_hk416_m203c", 
			"arifle_mas_hk416_m203c_h", 
			"arifle_mas_hk416_m203c_e", 
			"arifle_mas_hk416_m203c_sd", 
			"arifle_mas_hk416c_v", 
			"arifle_mas_hk416c_v_h", 
			"arifle_mas_hk416c_v_e", 
			"arifle_mas_hk416c_v_sd", 
			"arifle_mas_hk416_m203c_v", 
			"arifle_mas_hk416_m203c_v_h", 
			"arifle_mas_hk416_m203c_v_e", 
			"arifle_mas_hk416_m203c_v_sd", 
			"arifle_mas_hk416c_d", 
			"arifle_mas_hk416c_d_h", 
			"arifle_mas_hk416c_d_e", 
			"arifle_mas_hk416c_d_sd", 
			"arifle_mas_hk416_m203c_d", 
			"arifle_mas_hk416_m203c_d_h", 
			"arifle_mas_hk416_m203c_d_e", 
			"arifle_mas_hk416_m203c_d_sd", 
			"arifle_mas_hk417c", 
			"arifle_mas_hk417c_h", 
			"arifle_mas_hk417c_e", 
			"arifle_mas_hk417c_sd", 
			"arifle_mas_hk417_m203c", 
			"arifle_mas_hk417_m203c_h", 
			"arifle_mas_hk417_m203c_e", 
			"arifle_mas_hk417_m203c_sd", 
			"arifle_mas_hk417c_v", 
			"arifle_mas_hk417c_v_h", 
			"arifle_mas_hk417c_v_e", 
			"arifle_mas_hk417c_v_sd", 
			"arifle_mas_hk417_m203c_v", 
			"arifle_mas_hk417_m203c_v_h", 
			"arifle_mas_hk417_m203c_v_e", 
			"arifle_mas_hk417_m203c_v_sd", 
			"arifle_mas_hk417c_d", 
			"arifle_mas_hk417c_d_h", 
			"arifle_mas_hk417c_d_e", 
			"arifle_mas_hk417c_d_sd",
			"arifle_mas_ak_74m",
			"arifle_mas_aks74",
			"arifle_mas_ak74",
			"arifle_mas_ak_74m_sf",
			"arifle_mas_ak_74m_sf_c",
			"arifle_mas_aks_74_sf",
			"arifle_mas_ak12_sf",
			"arifle_mas_akms",
			"arifle_mas_akms_c",
			"arifle_mas_akm_a",
			"arifle_mas_aks74u",
			"arifle_mas_aks74u_c"
		};
	};

	class MASSniperRifles
	{
		name = "MASSniperRifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"srifle_mas_hk417_sd",
			"srifle_mas_hk417_v_sd",
			"srifle_mas_hk417_d_sd",
			"srifle_mas_sr25_sd",
			"srifle_mas_sr25_v_sd",
			"srifle_mas_sr25_d_sd",
			"srifle_mas_ebr_sd",
			"srifle_mas_mk17s_sd",
			"srifle_mas_m110_sd",
			"srifle_mas_m107",
			"srifle_mas_m107_v",
			"srifle_mas_m107_d",
			"srifle_mas_m24",
			"srifle_mas_m24_v",
			"srifle_mas_m24_d",
			"srifle_mas_lrr"
		};
	};

	class MASCars
	{
		name = "MASCars";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_mas_HMMWV_M2", 
			"B_mas_HMMWV_M134", 
			"B_mas_HMMWV_SOV", 
			"B_mas_HMMWV_SOV_M134", 
			"B_mas_HMMWV_TOW", 
			"B_mas_HMMWV_MK19", 
			"B_mas_HMMWV_UNA", 
			"B_mas_HMMWV_MEV", 
			"B_mas_HMMWV_M2_des", 
			"B_mas_HMMWV_M134_des", 
			"B_mas_HMMWV_SOV_des", 
			"B_mas_HMMWV_SOV_M134_des", 
			"B_mas_HMMWV_TOW_des", 
			"B_mas_HMMWV_MK19_des", 
			"B_mas_HMMWV_UNA_des", 
			"B_mas_HMMWV_MEV_des", 
			"B_mas_cars_Hilux_MG",  
			"B_mas_cars_Hilux_AGS30", 
			"B_mas_cars_Hilux_SPG9",  
			"B_mas_cars_Hilux_RKTS",  
			"B_mas_cars_Hilux_Unarmed",  
			"B_mas_cars_Hilux_Med", 
			"B_mas_cars_Hilux_M2", 
			"B_mas_cars_LR_Unarmed", 
			"B_mas_cars_LR_Med", 
			"B_mas_cars_LR_M2", 
			"B_mas_cars_LR_Mk19", 
			"B_mas_cars_LR_TOW", 
			"B_mas_cars_LR_SPG9",
			"B_mas_usn_Offroad_01_F", 
			"B_mas_usn_Offroad_01_armed_F", 
			"B_mas_usd_Offroad_01_F", 
			"B_mas_usd_Offroad_01_armed_F", 
			"B_mas_usd_Offroad_02_F", 
			"B_mas_usd_Offroad_02_armed_F", 
			"B_mas_usr_MRAP_01_F", 
			"B_mas_usr_MRAP_01_med_F", 
			"B_mas_usr_MRAP_01_gmg_F", 
			"B_mas_usr_MRAP_01_hmg_F", 
			"B_mas_usr_HMMWV_M2", 
			"B_mas_usr_HMMWV_TOW", 
			"B_mas_usr_HMMWV_MK19", 
			"B_mas_usr_HMMWV_UNA", 
			"B_mas_usr_HMMWV_MEV", 
			"B_mas_usr_HMMWV_M134", 
			"B_mas_usr_HMMWV_SOV", 
			"B_mas_usr_HMMWV_SOV_M134", 
			"B_mas_usr_Quadbike_01_F", 
			"B_mas_usr_Quadbike_02_F", 
			"B_mas_usr_Quadbike_03_F", 
			"B_mas_usr_Quadbike_04_F", 
			"B_mas_usr_APC_Wheeled_01_cannon_F"
		};
	};

	class MASTrucks
	{
		name = "MASTrucks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_mas_usr_Truck_01_covered_F", 
			"B_mas_usr_Truck_01_transport_F", 
			"B_mas_usr_Truck_01_reammo_F", 
			"B_mas_usr_Truck_01_refuel_F", 
			"B_mas_usr_Truck_01_repair_F"
		};
	};

	class MASChoppers
	{
		name = "MASChoppers";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_mas_usr_Heli_Light_01_F", 
			"B_mas_usr_Heli_Light_01_armed_F", 
			"B_mas_usr_Heli_Transport_01_F", 
			"B_mas_usr_Heli_Med_01_F", 
			"B_mas_usr_UH60M", 
			"B_mas_usr_UH60M_SF", 
			"B_mas_usr_UH60M_MEV", 
			"B_mas_usr_CH_47F",
			"B_mas_CH_47F",
			"B_mas_UH1Y_F", 
			"B_mas_UH1Y_UNA_F", 
			"B_mas_UH1Y_MEV_F",
			"B_mas_UH60M", 
			"B_mas_UH60M_SF", 
			"B_mas_UH60M_MEV"
		};
	};

	class MASBoats
	{
		name = "MASBoats";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_mas_usr_Boat_Transport_01_F", 
			"B_mas_usr_Boat_Armed_01_F", 
			"B_mas_usn_SDV_01_F"
		};
	};

	class MASPlanes
	{
		name = "Planes";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"mas_F_35C", 
			"mas_F_35C_S",
			"mas_F_35C_cas"
		};
	};

	


