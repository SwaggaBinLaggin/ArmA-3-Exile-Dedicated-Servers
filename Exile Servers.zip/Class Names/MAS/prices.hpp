

	///////////////////////////////////////////////////////////////////////////////
	// Soldier Uniforms
	///////////////////////////////////////////////////////////////////////////////

	class U_mas_sfod_B_CombatUniform_wood 			{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_wood_tshirt 	{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_wood_vest 		{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_wood_vest1 	{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_wood_vest2 	{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_wood_vest3 	{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_wood_vest4 	{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_des 			{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_des_tshirt 	{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_des_vest 		{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_des_vest1 		{ quality = 1; price = 40; };
	class U_mas_sfod_B_CombatUniform_des_vest2 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_mcam 			{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_mcam_tshirt 	{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_mcam_vest 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_mcam_vest1 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_mcam_vest2 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_mcam_vest3 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_mcam_vest4 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_veg 			{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_veg_tshirt 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_veg_vest 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_veg_vest1 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_veg_vest2 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_des 			{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_des_tshirt 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_des_vest 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_des_vest1 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_des_vest2 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_sage 			{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_sage_tshirt 	{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_sage_vest 		{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_wood 			{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_wood_tshirt 	{ quality = 1; price = 40; };
	class U_mas_usn_B_CombatUniform_wood_vest 		{ quality = 1; price = 40; };
	class U_mas_usd_B_CombatUniform_mcam 			{ quality = 1; price = 40; };
	class U_mas_usd_B_CombatUniform_mcam_tshirt 	{ quality = 1; price = 40; };
	class U_mas_usd_B_CombatUniform_mcam_vest 		{ quality = 1; price = 40; };
	class U_mas_usd_B_CombatUniform_mcam_vest1 		{ quality = 1; price = 40; };
	class U_mas_usr_B_IndUniform1_o 				{ quality = 1; price = 40; };
	class U_mas_usr_B_IndUniform2_o 				{ quality = 1; price = 40; };
	class U_mas_usr_B_IndUniform1_v 				{ quality = 1; price = 40; };
	class U_mas_usr_B_IndUniform2_v 				{ quality = 1; price = 40; };
	class U_mas_usr_B_IndUniform1_d 				{ quality = 1; price = 40; };
	class U_mas_usr_B_IndUniform2_d 				{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform1_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform2_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform3_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform4_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform5_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform6_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform7_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform8_o 					{ quality = 1; price = 40; };
	class U_mas_usd_B_founiform9_o 					{ quality = 1; price = 40; };
	class U_mas_usn_B_DEV 							{ quality = 1; price = 40; };
	class U_mas_usn_B_wint 							{ quality = 1; price = 40; };
	class U_mas_usn_B_pilot 						{ quality = 1; price = 40; };
	
	
	///////////////////////////////////////////////////////////////////////////////
	// Ghillie Suits
	///////////////////////////////////////////////////////////////////////////////
	class U_mas_usn_B_GhillieSuit 					{ quality = 3; price = 150; };		
	class U_mas_usn_B_GhillieSuit_v 				{ quality = 3; price = 150; };
	class U_mas_usn_B_GhillieSuit_d 				{ quality = 3; price = 150; };
	class U_mas_usn_B_GhillieSuit_w					{ quality = 3; price = 150; };
	
	
	///////////////////////////////////////////////////////////////////////////////
	// Wet Suits
	///////////////////////////////////////////////////////////////////////////////
	class U_mas_usn_B_Wetsuit 						{ quality = 3; price = 80; };
	
		
	///////////////////////////////////////////////////////////////////////////////
	// Bandolliers
	///////////////////////////////////////////////////////////////////////////////
	class V_mas_usn_BandollierB_rgr					{ quality = 1; price = 30; };		
	class V_mas_usr_BandollierB_rgr_m				{ quality = 1; price = 30; };
	class V_mas_usn_BandollierB_rgr_d				{ quality = 1; price = 30; };
	class V_mas_usn_BandollierB_rgr_v				{ quality = 1; price = 30; };
	class V_mas_usn_BandollierB_rgr_g				{ quality = 1; price = 30; };
	class V_mas_usr_BandollierB_rgr					{ quality = 1; price = 30; };
	class V_mas_usr_BandollierB_rgr_d				{ quality = 1; price = 30; };
	class V_mas_usr_BandollierB_rgr_g				{ quality = 1; price = 30; };
	class V_mas_usn_Rangemaster_belt				{ quality = 1; price = 30; };
	class V_mas_usn_Rangemaster_belt_d				{ quality = 1; price = 30; };
	class V_mas_usn_Rangemaster_belt_v				{ quality = 1; price = 30; };
	class V_mas_usn_Rangemaster_belt_g				{ quality = 1; price = 30; };
	class V_mas_usr_Rangemaster_belt				{ quality = 1; price = 30; };
	class V_mas_usr_Rangemaster_belt_d				{ quality = 1; price = 30; };	
	class V_mas_usr_Rangemaster_belt_g				{ quality = 1; price = 30; };

	
	///////////////////////////////////////////////////////////////////////////////
	// Chestrigs
	///////////////////////////////////////////////////////////////////////////////
	class V_mas_usn_ChestrigB_rgr					{ quality = 1; price = 20; };
	class V_mas_usn_ChestrigB_rgr_d					{ quality = 1; price = 20; };
	class V_mas_usn_ChestrigB_rgr_v					{ quality = 1; price = 20; };
	class V_mas_usn_ChestrigB_rgr_g					{ quality = 1; price = 20; };
	class V_mas_usn_ChestrigB_rgr_w					{ quality = 1; price = 20; };
	class V_mas_usr_ChestrigB_rgr					{ quality = 1; price = 20; };
	class V_mas_usr_ChestrigB_rgr_d					{ quality = 1; price = 20; };
	class V_mas_usr_ChestrigB_rgr_g					{ quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Vests
	///////////////////////////////////////////////////////////////////////////////
	class V_mas_usn_TacVest_p 						{ quality = 2; price = 50; };
	class V_mas_usn_TacVest_g						{ quality = 2; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// Plate Carriers
	///////////////////////////////////////////////////////////////////////////////
	class V_mas_usn_PlateCarrier1_rgr	 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier2_rgr	 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrierGL_rgr				{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier1_rgr_m	 			{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier2_rgr_m				{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier1_rgr_d 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier2_rgr_d 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrierGL_rgr_d			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier1_rgr_v 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier2_rgr_v 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrierGL_rgr_v			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier1_rgr_g 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier2_rgr_g 			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrierGL_rgr_g			{ quality = 3; price = 200; };
	class V_mas_usn_PlateCarrier1_rgr_w				{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier1_rgr 				{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier2_rgr 				{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrierGL_rgr				{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier1_rgr_d 			{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier2_rgr_d 			{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrierGL_rgr_d			{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier1_rgr_g 			{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrier2_rgr_g 			{ quality = 3; price = 200; };
	class V_mas_usr_PlateCarrierGL_rgr_g  			{ quality = 3; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Caps
	///////////////////////////////////////////////////////////////////////////////
	class H_mas_usn_Cap_headphones 					{ quality = 1; price = 6; };
	class H_mas_usn_Cap_headphones_d 				{ quality = 1; price = 6; };
	class H_mas_usn_Cap_headphones_v 				{ quality = 1; price = 6; };
	class H_mas_usn_Cap_headphones_w 				{ quality = 1; price = 6; };
	class H_mas_usn_Cap_headphones_g				{ quality = 1; price = 6; };
	class H_mas_usn_revcapheadset_b 				{ quality = 1; price = 6; };
	class H_mas_usn_revcapheadset_v 				{ quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Military Caps
	///////////////////////////////////////////////////////////////////////////////
	class H_mas_usn_MilCap_mcamo 					{ quality = 1; price = 8; };
	class H_mas_usn_MilCap_mcamo_v 					{ quality = 1; price = 8; };
	class H_mas_usn_MilCap_mcamo_d					{ quality = 1; price = 8; };

	///////////////////////////////////////////////////////////////////////////////
	// Beanies
	///////////////////////////////////////////////////////////////////////////////
	class H_mas_usn_Woolhat 						{ quality = 1; price = 6; };
	class H_mas_usn_Woolhat_c 						{ quality = 1; price = 6; };
	class H_mas_usn_Woolhat_w 						{ quality = 1; price = 6; };
	class H_mas_usn_woolhat_ht 						{ quality = 1; price = 6; };
	class H_mas_usn_woolhat_ht_w					{ quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Bandannas
	///////////////////////////////////////////////////////////////////////////////
	class H_mas_usn_bandana 						{ quality = 1; price = 4; };
	class H_mas_usn_bandana_ht						{ quality = 1; price = 4; };

	///////////////////////////////////////////////////////////////////////////////
	// Boonie Hats
	///////////////////////////////////////////////////////////////////////////////
	class H_mas_usn_Booniehat_mul 					{ quality = 1; price = 6; };
	class H_mas_usd_Booniehat_mul 					{ quality = 1; price = 6; };
	class H_mas_usd_Booniehat_tan 					{ quality = 1; price = 6; };
	class H_mas_usn_Booniehat_rgr 					{ quality = 1; price = 6; };
	class H_mas_usn_Booniehat_des 					{ quality = 1; price = 6; };
	class H_mas_usr_Booniehat_rgr 					{ quality = 1; price = 6; };
	class H_mas_usr_Booniehat_des					{ quality = 1; price = 6; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Shemags
	///////////////////////////////////////////////////////////////////////////////
	class G_mas_wpn_gog 							{ quality = 1; price = 150; };
	class G_mas_wpn_gog_d							{ quality = 1; price = 150; };
	class G_mas_wpn_gog_m 							{ quality = 1; price = 150; };
	class G_mas_wpn_gog_md 							{ quality = 1; price = 150; };
	class G_mas_wpn_gog_g 							{ quality = 1; price = 150; };
	class G_mas_wpn_gog_gd 							{ quality = 1; price = 150; };
	class G_mas_wpn_mask 							{ quality = 1; price = 15; };
	class G_mas_wpn_mask_b 							{ quality = 1; price = 15; };
	class G_mas_wpn_wrap 							{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_f 							{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_t 							{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_b 							{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_c 							{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_g 							{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_gog 						{ quality = 1; price = 150; };
	class G_mas_wpn_wrap_gog_f 						{ quality = 1; price = 150; };
	class G_mas_wpn_wrap_gog_t 						{ quality = 1; price = 150; };
	class G_mas_wpn_wrap_gog_b 						{ quality = 1; price = 150; };
	class G_mas_wpn_wrap_gog_c 						{ quality = 1; price = 150; };
	class G_mas_wpn_wrap_gog_g 						{ quality = 1; price = 150; };
	class G_mas_wpn_wrap_mask 						{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_mask_t 					{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_mask_f 					{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_mask_b 					{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_mask_c 					{ quality = 1; price = 15; };
	class G_mas_wpn_wrap_mask_g 					{ quality = 1; price = 15; };
	class G_mas_wpn_bala 							{ quality = 1; price = 15; };
	class G_mas_wpn_bala_b 							{ quality = 1; price = 15; };
	class G_mas_wpn_bala_t 							{ quality = 1; price = 15; };
	class G_mas_wpn_bala_gog 						{ quality = 1; price = 150; };
	class G_mas_wpn_bala_gog_b 						{ quality = 1; price = 150; };
	class G_mas_wpn_bala_gog_t 						{ quality = 1; price = 150; };
	class G_mas_wpn_bala_mask 						{ quality = 1; price = 15; };
	class G_mas_wpn_bala_mask_b 					{ quality = 1; price = 15; };
	class G_mas_wpn_bala_mask_t 					{ quality = 1; price = 15; };
	class G_mas_wpn_shemag 							{ quality = 1; price = 15; };
	class G_mas_wpn_shemag_r 						{ quality = 1; price = 15; };
	class G_mas_wpn_shemag_w 						{ quality = 1; price = 15; };
	class G_mas_wpn_shemag_gog 						{ quality = 1; price = 150; };
	class G_mas_wpn_shemag_mask 					{ quality = 1; price = 15; };
	class G_mas_wpn_gasmask							{ quality = 1; price = 15; };

	///////////////////////////////////////////////////////////////////////////////
	// Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_mas_usn_helmet_mich_sf 					{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_g 				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_m 				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_w 				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_b 				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_gog				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_gog_g 			{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_gog_m 			{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_gog_w 			{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_gog_b 			{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_h 				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_h_g 				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_h_m  			{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_h_w 				{ quality = 2; price = 80; };
	class H_mas_usn_helmet_mich_sf_h_b 				{ quality = 2; price = 80; };

	///////////////////////////////////////////////////////////////////////////////
	// Spec Ops Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_mas_usn_helmet_ops_sf 					{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_b 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_g 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_d 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_w 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_e 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_v 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_m 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_z 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_b 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_g 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_d 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_w 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_e 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_v 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_m 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_gog_z 			{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_b 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_g 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_d 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_w 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_e 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_v 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_m 				{ quality = 2; price = 100; };
	class H_mas_usn_helmet_ops_sf_h_z				{ quality = 2; price = 100; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Pointer Attachments
	///////////////////////////////////////////////////////////////////////////////
	class acc_mas_flash_gun 						{ quality = 1; price = 10; };
	class acc_mas_pointer_gun_IR 					{ quality = 1; price = 20; };
	class acc_mas_pointer_IR 						{ quality = 1; price = 20; };
	class acc_mas_pointer_IR_b 						{ quality = 1; price = 20; };
	class acc_mas_pointer_IR_top 					{ quality = 1; price = 20; };
	class acc_mas_pointer_IR_top_b 					{ quality = 1; price = 20; };
	class acc_mas_pointer_IR2 						{ quality = 1; price = 20; };
	class acc_mas_pointer_IR2_top 					{ quality = 1; price = 20; };
	class acc_mas_pointer_IR2c 						{ quality = 1; price = 20; };
	class acc_mas_pointer_IR2c_top					{ quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Muzzle Attachments
	///////////////////////////////////////////////////////////////////////////////
	class muzzle_mas_snds_L 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_LM 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_C 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_MP5SD6 					{ quality = 1; price = 20; };
	class muzzle_mas_snds_M 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_Mc 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_MP7 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_AK 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_SM 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_SMc 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_SH 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_SHc 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_SV 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_SVc 						{ quality = 1; price = 20; };
	class muzzle_mas_snds_SVD						{ quality = 1; price = 20; };
	class muzzle_mas_snds_KSVK						{ quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Optic Attachments
	///////////////////////////////////////////////////////////////////////////////
	class optic_mas_DMS 							{ quality = 1; price = 50; };
	class optic_mas_DMS_c 							{ quality = 1; price = 50; };
	class optic_mas_Holosight_blk 					{ quality = 1; price = 50; };
	class optic_mas_Holosight_camo 					{ quality = 1; price = 50; };
	class optic_mas_Arco_blk 						{ quality = 1; price = 50; };
	class optic_mas_Arco_camo						{ quality = 1; price = 50; };
	class optic_mas_Hamr_camo	 					{ quality = 1; price = 50; };
	class optic_mas_Aco_camo 						{ quality = 1; price = 50; };
	class optic_mas_ACO_grn_camo 					{ quality = 1; price = 50; };
	class optic_mas_MRCO_camo 						{ quality = 1; price = 50; };
	class optic_mas_zeiss 							{ quality = 1; price = 50; };
	class optic_mas_zeiss_c 						{ quality = 1; price = 50; };
	class optic_mas_zeiss_eo 						{ quality = 1; price = 50; };
	class optic_mas_zeiss_eo_c 						{ quality = 1; price = 50; };
	class optic_mas_acog 							{ quality = 1; price = 50; };
	class optic_mas_acog_c 							{ quality = 1; price = 50; };
	class optic_mas_acog_eo 						{ quality = 1; price = 50; };
	class optic_mas_acog_eo_c 						{ quality = 1; price = 50; };
	class optic_mas_acog_rd 						{ quality = 1; price = 50; };
	class optic_mas_acog_rd_c 						{ quality = 1; price = 50; };
	class optic_mas_handle 							{ quality = 1; price = 50; };
	class optic_mas_aim 							{ quality = 1; price = 50; };
	class optic_mas_aim_c 							{ quality = 1; price = 50; };
	class optic_mas_PSO 							{ quality = 1; price = 50; };
	class optic_mas_PSO_c 							{ quality = 1; price = 50; };
	class optic_mas_PSO_eo 							{ quality = 1; price = 50; };
	class optic_mas_PSO_eo_c 						{ quality = 1; price = 50; };
	class optic_mas_PSO_nv 							{ quality = 1; price = 50; };
	class optic_mas_PSO_nv_c 						{ quality = 1; price = 50; };
	class optic_mas_PSO_nv_eo 						{ quality = 1; price = 50; };
	class optic_mas_PSO_nv_eo_c 					{ quality = 1; price = 50; };
	class optic_mas_PSO_day 						{ quality = 1; price = 50; };
	class optic_mas_PSO_nv_day 						{ quality = 1; price = 50; };
	class optic_mas_term 							{ quality = 1; price = 50; };
	class optic_mas_MRD 							{ quality = 1; price = 50; };
	class optic_mas_LRPS 							{ quality = 1; price = 50; };
	class optic_mas_kobra 							{ quality = 1; price = 50; };
	class optic_mas_kobra_c 						{ quality = 1; price = 50; };
	class optic_mas_nspu 							{ quality = 1; price = 50; };
	class optic_mas_goshawk 						{ quality = 1; price = 50; };
	class optic_mas_PSO_kv 							{ quality = 1; price = 50; };
	class optic_mas_PSO_kv_c						{ quality = 1; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// Backpacks
	///////////////////////////////////////////////////////////////////////////////
	class B_mas_m_Bergen_us                        { quality = 10; price = 20; };
	class B_mas_m_Bergen_us_g                      { quality = 10; price = 20; };
	class B_mas_m_Bergen_us_m                      { quality = 10; price = 20; };
	class B_mas_m_Bergen_us_b                      { quality = 10; price = 20; };
	class B_mas_m_Bergen_us_w                      { quality = 10; price = 20; };
	class B_mas_m_Bergen_acr                       { quality = 10; price = 20; };
	class B_mas_m_Bergen_acr_c                     { quality = 10; price = 20; };
	class B_mas_m_Bergen_acr_g                     { quality = 10; price = 20; };
	class B_mas_m_Bergen_acr_w                     { quality = 10; price = 20; }; 
	class B_mas_m_Bergen_rpg                       { quality = 10; price = 20; };  
	class B_mas_m_Bergen_rpg_b                     { quality = 10; price = 20; }; 
	class B_mas_m_Bergen_al                        { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul                    { quality = 10; price = 20; }; 
	class B_mas_Kitbag_mul                         { quality = 10; price = 20; }; 
	class B_mas_Bergen_mul                         { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_ammo               { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_ammo_MG            { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_Medic              { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_AA                 { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_AT                 { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_AT4                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_m72                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_MAAWS              { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_SMAW               { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_ATM                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_mul_Repair             { quality = 10; price = 20; }; 
	class B_mas_Bergen_mul_Exp                     { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des                    { quality = 10; price = 20; }; 
	class B_mas_Kitbag_des                         { quality = 10; price = 20; }; 
	class B_mas_Bergen_des                         { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_Medic              { quality = 10; price = 20; };
	class B_mas_AssaultPack_des_AA                 { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_AT                 { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_AT4                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_m72                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_MAAWS              { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_SMAW               { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_ATM                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_des_Repair             { quality = 10; price = 20; }; 
	class B_mas_Bergen_des_Exp                     { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black                  { quality = 10; price = 20; }; 
	class B_mas_Kitbag_black                       { quality = 10; price = 20; }; 
	class B_mas_Bergen_black                       { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black_Medic            { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black_AA               { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black_AT               { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black_AT4              { quality = 10; price = 20; };
	class B_mas_AssaultPack_black_m72              { quality = 10; price = 20; };
	class B_mas_AssaultPack_black_MAAWS            { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black_SMAW             { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black_ATM              { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_black_Repair           { quality = 10; price = 20; };
	class B_mas_Bergen_black_Exp                   { quality = 10; price = 20; };
	class B_mas_AssaultPack_rng                    { quality = 10; price = 20; }; 
	class B_mas_Kitbag_rng						   { quality = 10; price = 20; }; 
	class B_mas_Bergen_rng                         { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_Medic              { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_AA                 { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_AT                 { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_AT4                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_m72                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_MAAWS              { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_SMAW               { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_ATM                { quality = 10; price = 20; }; 
	class B_mas_AssaultPack_rng_Repair             { quality = 10; price = 20; }; 
	class B_mas_Bergen_rng_Exp                     { quality = 10; price = 20; };
			
	///////////////////////////////////////////////////////////////////////////////
	// Ammunition
	///////////////////////////////////////////////////////////////////////////////
	class 30Rnd_mas_556x45_Stanag 					{ quality = 10; price = 20; };
	class 30Rnd_mas_556x45_T_Stanag 				{ quality = 10; price = 20; };
	class 200Rnd_mas_556x45_Stanag 					{ quality = 10; price = 20; };
	class 200Rnd_mas_556x45_T_Stanag 				{ quality = 10; price = 20; };
	class 100Rnd_mas_762x51_Stanag 					{ quality = 10; price = 20; };
	class 100Rnd_mas_762x51_T_Stanag 				{ quality = 10; price = 20; };
	class 100Rnd_mas_762x54_mag 					{ quality = 10; price = 20; };
	class 100Rnd_mas_762x54_T_mag 					{ quality = 10; price = 20; };
	class 100Rnd_mas_762x39_mag 					{ quality = 10; price = 20; };
	class 100Rnd_mas_762x39_T_mag 					{ quality = 10; price = 20; };
	class 30Rnd_mas_545x39_mag 						{ quality = 10; price = 20; };
	class 30Rnd_mas_545x39_T_mag 					{ quality = 10; price = 20; };
	class 100Rnd_mas_545x39_mag 					{ quality = 10; price = 20; };
	class 100Rnd_mas_545x39_T_mag 					{ quality = 10; price = 20; };
	class 20Rnd_mas_762x51_Stanag 					{ quality = 10; price = 20; };
	class 20Rnd_mas_762x51_T_Stanag 				{ quality = 10; price = 20; };
	class 5Rnd_mas_762x51_Stanag 					{ quality = 10; price = 20; };
	class 5Rnd_mas_762x51_T_Stanag 					{ quality = 10; price = 20; };
	class 10Rnd_mas_338_Stanag 						{ quality = 10; price = 20; };
	class 10Rnd_mas_338_T_Stanag 					{ quality = 10; price = 20; };
	class 30Rnd_mas_762x39_mag 						{ quality = 10; price = 20; };
	class 30Rnd_mas_762x39_T_mag 					{ quality = 10; price = 20; };
	class 10Rnd_mas_762x54_mag 						{ quality = 10; price = 20; };
	class 10Rnd_mas_762x54_T_mag 					{ quality = 10; price = 20; };
	class 5Rnd_mas_127x99_Stanag 					{ quality = 10; price = 20; };
	class 5Rnd_mas_127x99_dem_Stanag 				{ quality = 10; price = 20; };
	class 5Rnd_mas_127x99_T_Stanag 					{ quality = 10; price = 20; };
	class 5Rnd_mas_127x108_mag						{ quality = 10; price = 20; };
	class 5Rnd_mas_127x108_dem_mag 					{ quality = 10; price = 20; };
	class 5Rnd_mas_127x108_T_mag 					{ quality = 10; price = 20; };
	class 30Rnd_mas_9x21_Stanag 					{ quality = 10; price = 20; };
	class 30Rnd_mas_9x21d_Stanag 					{ quality = 10; price = 20; };
	class 12Rnd_mas_45acp_Mag 						{ quality = 10; price = 20; };
	class 10Rnd_mas_45acp_Mag 						{ quality = 10; price = 20; };
	class 8Rnd_mas_45acp_Mag 						{ quality = 10; price = 20; };
	class 15Rnd_mas_9x21_Mag 						{ quality = 10; price = 20; };
	class 17Rnd_mas_9x21_Mag 						{ quality = 10; price = 20; };
	class 13Rnd_mas_9x21_Mag 						{ quality = 10; price = 20; };
	class 8Rnd_mas_9x18_mag							{ quality = 10; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Pistols
	///////////////////////////////////////////////////////////////////////////////
	class hgun_mas_m9_F								{ quality = 1; price = 50; };
	class hgun_mas_glock_F							{ quality = 1; price = 50; };
	class hgun_mas_p226_F							{ quality = 1; price = 50; };
	class hgun_mas_bhp_F							{ quality = 1; price = 50; };
	class hgun_mas_m9_F_sd							{ quality = 1; price = 50; };
	class hgun_mas_bhp_F_sd							{ quality = 1; price = 50; };
	class hgun_mas_glock_F_sd						{ quality = 1; price = 50; };
	class hgun_mas_p226_F_sd						{ quality = 1; price = 50; };
	class hgun_mas_grach_F							{ quality = 1; price = 50; };
	class hgun_mas_mak_F_sd							{ quality = 1; price = 50; };
	class hgun_mas_acp_F 							{ quality = 1; price = 50; };
	class hgun_mas_acp_F_sd 						{ quality = 1; price = 50; };
	class hgun_mas_usp_F 							{ quality = 1; price = 50; };
	class hgun_mas_usp_l_F 							{ quality = 1; price = 50; };
	class hgun_mas_glocksf_F 						{ quality = 1; price = 50; };
	class hgun_mas_glocksf_F_sd 					{ quality = 1; price = 50; };
	class hgun_mas_usp_F_sd 						{ quality = 1; price = 50; };
	class hgun_mas_usp_l_F_sd						{ quality = 1; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// Sub Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_mp5_sd							{ quality = 1; price = 150; };
	class arifle_mas_mp5_v_sd						{ quality = 1; price = 150; };
	class arifle_mas_mp5_d_sd						{ quality = 1; price = 150; };
	class hgun_mas_mp7_F_sd							{ quality = 1; price = 150; };
	class hgun_mas_mp7p_F_sd						{ quality = 1; price = 150; };
	class hgun_mas_uzi_F							{ quality = 1; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Light Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class LMG_mas_Mk200_F_a							{ quality = 3; price = 250; };
	class LMG_mas_Mk200_F_sd						{ quality = 3; price = 250; };
	class LMG_mas_M249_F_a							{ quality = 3; price = 250; };
	class LMG_mas_M249_F_sd							{ quality = 3; price = 250; };
	class LMG_mas_M249_F_v_a						{ quality = 3; price = 250; };
	class LMG_mas_M249_F_v_sd						{ quality = 3; price = 250; };
	class LMG_mas_M249_F_d_a						{ quality = 3; price = 250; };
	class LMG_mas_M249_F_d_sd						{ quality = 3; price = 250; };
	class LMG_mas_Mk48_F_a							{ quality = 3; price = 250; };
	class LMG_mas_Mk48_F_v							{ quality = 3; price = 250; };
	class LMG_mas_Mk48_F_v_a						{ quality = 3; price = 250; };
	class LMG_mas_Mk48_F_d							{ quality = 3; price = 250; };
	class LMG_mas_Mk48_F_d_a						{ quality = 3; price = 250; };
	class LMG_mas_M240_F_a							{ quality = 3; price = 250; };
	class LMG_mas_M60_F								{ quality = 3; price = 250; };
	class LMG_mas_M60_F_a							{ quality = 3; price = 250; };
	class LMG_mas_rpk_F								{ quality = 3; price = 250; };
	class LMG_mas_pkm_F								{ quality = 3; price = 250; };

	///////////////////////////////////////////////////////////////////////////////
	// Assault Rifles
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_hk416 							{ quality = 1; price = 150; };
	class arifle_mas_hk416_a 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_e 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_sd 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_m203 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_t 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_a 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_e 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_sd 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_v 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_v_a 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_v_e 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_v_sd 					{ quality = 1; price = 150; };
	class arifle_mas_hk416_m203_v  					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_v_a 				{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_v_e 				{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_v_sd 				{ quality = 1; price = 450; };
	class arifle_mas_hk416_d  						{ quality = 1; price = 150; };
	class arifle_mas_hk416_d_a 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_d_e 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_d_sd 					{ quality = 1; price = 150; };
	class arifle_mas_hk416_m203_d 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_d_a 				{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_d_e 				{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203_d_sd 				{ quality = 1; price = 450; };
	class arifle_mas_hk416c 						{ quality = 1; price = 150; };
	class arifle_mas_hk416c_h 						{ quality = 1; price = 150; };
	class arifle_mas_hk416c_e 						{ quality = 1; price = 150; };
	class arifle_mas_hk416c_sd 						{ quality = 1; price = 150; };
	class arifle_mas_hk416_m203c 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203c_e 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203c_sd 				{ quality = 1; price = 450; };
	class arifle_mas_hk416c_v 						{ quality = 1; price = 150; };
	class arifle_mas_hk416c_v_e 					{ quality = 1; price = 150; };
	class arifle_mas_hk416c_v_sd 					{ quality = 1; price = 150; };
	class arifle_mas_hk416_m203c_v 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203c_v_e 				{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203c_v_sd 				{ quality = 1; price = 450; };
	class arifle_mas_hk416c_d 						{ quality = 1; price = 150; };
	class arifle_mas_hk416c_d_e 					{ quality = 1; price = 150; };
	class arifle_mas_hk416c_d_sd 					{ quality = 1; price = 150; };
	class arifle_mas_hk416_m203c_d 					{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203c_d_e 				{ quality = 1; price = 450; };
	class arifle_mas_hk416_m203c_d_sd 				{ quality = 1; price = 450; };
	class arifle_mas_hk417c 						{ quality = 1; price = 150; };
	class arifle_mas_hk417c_e 						{ quality = 1; price = 150; };
	class arifle_mas_hk417c_sd 						{ quality = 1; price = 150; };
	class arifle_mas_hk417_m203c 					{ quality = 1; price = 450; };
	class arifle_mas_hk417_m203c_e 					{ quality = 1; price = 450; };
	class arifle_mas_hk417_m203c_sd 				{ quality = 1; price = 450; };
	class arifle_mas_hk417c_v 						{ quality = 1; price = 150; };
	class arifle_mas_hk417c_v_e 					{ quality = 1; price = 150; };
	class arifle_mas_hk417c_v_sd 					{ quality = 1; price = 150; };
	class arifle_mas_hk417_m203c_v 					{ quality = 1; price = 450; };
	class arifle_mas_hk417_m203c_v_e 				{ quality = 1; price = 450; };
	class arifle_mas_hk417_m203c_v_sd 				{ quality = 1; price = 450; };
	class arifle_mas_hk417c_d 						{ quality = 1; price = 150; };
	class arifle_mas_hk417c_d_e 					{ quality = 1; price = 150; };
	class arifle_mas_hk417c_d_sd					{ quality = 1; price = 150; };
	class arifle_mas_hk417_m203c_d 					{ quality = 1; price = 450; };
	class arifle_mas_hk417_m203c_d_e 				{ quality = 1; price = 450; };
	class arifle_mas_hk417_m203c_d_sd				{ quality = 1; price = 450; };
	class arifle_mas_m4								{ quality = 1; price = 150; };
	class arifle_mas_m4_a							{ quality = 1; price = 150; };
	class arifle_mas_m4_e							{ quality = 1; price = 150; };
	class arifle_mas_m4_sd							{ quality = 1; price = 150; };
	class arifle_mas_m4_d							{ quality = 1; price = 150; };
	class arifle_mas_m4_d_a							{ quality = 1; price = 150; };
	class arifle_mas_m4_d_e							{ quality = 1; price = 150; };
	class arifle_mas_m4_d_sd						{ quality = 1; price = 150; };
	class arifle_mas_m4vlt							{ quality = 1; price = 150; };
	class arifle_mas_m4vlt_e						{ quality = 1; price = 150; };
	class arifle_mas_m4vlt_sd						{ quality = 1; price = 150; };
	class arifle_mas_m4c							{ quality = 1; price = 150; };
	class arifle_mas_m4c_e							{ quality = 1; price = 150; };
	class arifle_mas_m4c_sd							{ quality = 1; price = 150; };
	class arifle_mas_l119_sd						{ quality = 1; price = 150; };
	class arifle_mas_l119c_sd						{ quality = 1; price = 150; };
	class arifle_mas_l119_m203_sd					{ quality = 1; price = 450; };
	class arifle_mas_l119c_v_sd						{ quality = 1; price = 150; };
	class arifle_mas_l119_gl_v_sd					{ quality = 1; price = 450; };
	class arifle_mas_l119_m203_v_sd					{ quality = 1; price = 450; };
	class arifle_mas_l119_d_sd						{ quality = 1; price = 150; };
	class arifle_mas_l119_gl_d_sd					{ quality = 1; price = 450; };
	class arifle_mas_l119_m203_d_sd					{ quality = 1; price = 450; };
	class arifle_mas_g36c_sd						{ quality = 1; price = 150; };
	class arifle_mas_mk16_sd						{ quality = 1; price = 150; };
	class arifle_mas_mk16_gl_sd						{ quality = 1; price = 450; };
	class arifle_mas_mk16_l_sd						{ quality = 1; price = 150; };
	class arifle_mas_mk16_l_gl_sd					{ quality = 1; price = 450; };
	class arifle_mas_mk17_sd						{ quality = 1; price = 150; };
	class arifle_mas_mk17_gl_sd						{ quality = 1; price = 450; };
	class arifle_mas_arx_sd							{ quality = 1; price = 150; };
	class arifle_mas_arx_gl_sd						{ quality = 1; price = 450; };
	class arifle_mas_arx_l_sd						{ quality = 1; price = 150; };
	class arifle_mas_arx_l_gl_sd					{ quality = 1; price = 450; };
	class arifle_mas_m14_a							{ quality = 1; price = 150; };
	class arifle_mas_m14_l							{ quality = 1; price = 150; };
	class arifle_mas_ak_74m							{ quality = 1; price = 150; };
	class arifle_mas_aks74							{ quality = 1; price = 150; };
	class arifle_mas_ak74							{ quality = 1; price = 150; };
	class arifle_mas_ak_74m_sf						{ quality = 1; price = 150; };
	class arifle_mas_ak_74m_sf_c					{ quality = 1; price = 150; };
	class arifle_mas_aks_74_sf						{ quality = 1; price = 150; };
	class arifle_mas_ak12_sf						{ quality = 1; price = 150; };
	class arifle_mas_akms							{ quality = 1; price = 150; };
	class arifle_mas_akms_c							{ quality = 1; price = 150; };
	class arifle_mas_akm_a							{ quality = 1; price = 150; };
	class arifle_mas_aks74u							{ quality = 1; price = 150; };
	class arifle_mas_aks74u_c						{ quality = 1; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Sniper Rifles
	///////////////////////////////////////////////////////////////////////////////
	class srifle_mas_hk417_sd						{ quality = 1; price = 550; };
	class srifle_mas_hk417_v_sd						{ quality = 1; price = 550; };
	class srifle_mas_hk417_d_sd						{ quality = 1; price = 550; };
	class srifle_mas_sr25_sd						{ quality = 1; price = 550; };
	class srifle_mas_sr25_v_sd						{ quality = 1; price = 550; };
	class srifle_mas_sr25_d_sd						{ quality = 1; price = 550; };
	class srifle_mas_ebr_sd							{ quality = 1; price = 550; };
	class srifle_mas_mk17s_sd						{ quality = 1; price = 550; };
	class srifle_mas_m110_sd						{ quality = 1; price = 1550; };
	class srifle_mas_m107							{ quality = 1; price = 1550; };
	class srifle_mas_m107_v							{ quality = 1; price = 1550; };
	class srifle_mas_m107_d							{ quality = 1; price = 1550; };
	class srifle_mas_m24							{ quality = 1; price = 550; };
	class srifle_mas_m24_v							{ quality = 1; price = 550; };
	class srifle_mas_m24_d							{ quality = 1; price = 550; };
	class srifle_mas_lrr							{ quality = 1; price = 250; };

	///////////////////////////////////////////////////////////////////////////////
	// Massi Vehicles
	///////////////////////////////////////////////////////////////////////////////
	class B_mas_usr_Truck_01_covered_F 					{ quality = 1; price = 3000; };
	class B_mas_usr_Truck_01_transport_F 				{ quality = 1; price = 3000; };
	class B_mas_usr_Truck_01_reammo_F 					{ quality = 1; price = 3000; };
	class B_mas_usr_Truck_01_refuel_F 					{ quality = 1; price = 3000; };
	class B_mas_usr_Truck_01_repair_F					{ quality = 1; price = 3000; };
	class B_mas_HMMWV_M2								{ quality = 1; price = 3000; };
	class B_mas_HMMWV_M134 								{ quality = 1; price = 3000; };
	class B_mas_HMMWV_SOV								{ quality = 1; price = 3000; };
	class B_mas_HMMWV_SOV_M134							{ quality = 1; price = 3000; };
	class B_mas_HMMWV_TOW								{ quality = 1; price = 3000; };
	class B_mas_HMMWV_MK19								{ quality = 1; price = 3000; };
	class B_mas_HMMWV_UNA								{ quality = 1; price = 3000; };
	class B_mas_HMMWV_MEV								{ quality = 1; price = 3000; };
	class B_mas_HMMWV_M2_des							{ quality = 1; price = 3000; };
	class B_mas_HMMWV_M134_des							{ quality = 1; price = 3000; };
	class B_mas_HMMWV_SOV_des							{ quality = 1; price = 3000; };
	class B_mas_HMMWV_SOV_M134_des						{ quality = 1; price = 3000; };
	class B_mas_HMMWV_TOW_des							{ quality = 1; price = 3000; };
	class B_mas_HMMWV_MK19_des							{ quality = 1; price = 3000; };
	class B_mas_HMMWV_UNA_des							{ quality = 1; price = 3000; };
	class B_mas_HMMWV_MEV_des							{ quality = 1; price = 3000; };
	class B_mas_cars_Hilux_MG							{ quality = 1; price = 3000; };
	class B_mas_cars_Hilux_AGS30						{ quality = 1; price = 3000; };
	class B_mas_cars_Hilux_SPG9							{ quality = 1; price = 3000; };
	class B_mas_cars_Hilux_RKTS							{ quality = 1; price = 3000; };
	class B_mas_cars_Hilux_Unarmed						{ quality = 1; price = 3000; };
	class B_mas_cars_Hilux_Med							{ quality = 1; price = 3000; };
	class B_mas_cars_Hilux_M2							{ quality = 1; price = 3000; };
	class B_mas_cars_LR_Unarmed							{ quality = 1; price = 3000; };
	class B_mas_cars_LR_Med								{ quality = 1; price = 3000; };
	class B_mas_cars_LR_M2								{ quality = 1; price = 3000; };
	class B_mas_cars_LR_Mk19							{ quality = 1; price = 3000; };
	class B_mas_cars_LR_TOW								{ quality = 1; price = 3000; };
	class B_mas_cars_LR_SPG9							{ quality = 1; price = 3000; };
	class B_mas_usn_Offroad_01_F						{ quality = 1; price = 3000; };
	class B_mas_usn_Offroad_01_armed_F					{ quality = 1; price = 3000; };
	class B_mas_usd_Offroad_01_F						{ quality = 1; price = 3000; };
	class B_mas_usd_Offroad_01_armed_F					{ quality = 1; price = 3000; };
	class B_mas_usd_Offroad_02_F						{ quality = 1; price = 3000; };
	class B_mas_usd_Offroad_02_armed_F					{ quality = 1; price = 3000; };
	class B_mas_usr_MRAP_01_F							{ quality = 1; price = 3000; };
	class B_mas_usr_MRAP_01_med_F						{ quality = 1; price = 3000; };
	class B_mas_usr_MRAP_01_gmg_F						{ quality = 1; price = 3000; };
	class B_mas_usr_MRAP_01_hmg_F						{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_M2							{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_TOW							{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_MK19 							{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_UNA 							{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_MEV 							{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_M134 							{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_SOV 							{ quality = 1; price = 3000; };
	class B_mas_usr_HMMWV_SOV_M134 						{ quality = 1; price = 3000; };
	class B_mas_usr_Quadbike_01_F 						{ quality = 1; price = 3000; };
	class B_mas_usr_Quadbike_02_F 						{ quality = 1; price = 3000; };
	class B_mas_usr_Quadbike_03_F 						{ quality = 1; price = 3000; };
	class B_mas_usr_Quadbike_04_F 						{ quality = 1; price = 3000; };
	class B_mas_usr_APC_Wheeled_01_cannon_F				{ quality = 1; price = 3000; };
	class B_mas_usr_Heli_Light_01_F						{ quality = 1; price = 8200; };
	class B_mas_usr_Heli_Light_01_armed_F				{ quality = 1; price = 8200; };
	class B_mas_usr_Heli_Transport_01_F					{ quality = 1; price = 8200; };
	class B_mas_usr_Heli_Med_01_F						{ quality = 1; price = 8200; };
	class B_mas_usr_UH60M								{ quality = 1; price = 8200; };
	class B_mas_usr_UH60M_SF							{ quality = 1; price = 8200; };
	class B_mas_usr_UH60M_MEV							{ quality = 1; price = 8200; };
	class B_mas_usr_CH_47F								{ quality = 1; price = 8200; };
	class B_mas_CH_47F									{ quality = 1; price = 8200; };
	class B_mas_UH1Y_F 									{ quality = 1; price = 8200; };
	class B_mas_UH1Y_UNA_F 								{ quality = 1; price = 8200; };
	class B_mas_UH1Y_MEV_F								{ quality = 1; price = 8200; };
	class B_mas_UH60M 									{ quality = 1; price = 8200; };
	class B_mas_UH60M_SF 								{ quality = 1; price = 8200; };
	class B_mas_UH60M_MEV								{ quality = 1; price = 8200; };
	class mas_F_35C		 								{ quality = 1; price = 8200; };
	class mas_F_35C_S 									{ quality = 1; price = 8200; };
	class mas_F_35C_cas									{ quality = 1; price = 8200; };
	class B_mas_usr_Boat_Transport_01_F 				{ quality = 1; price = 8200; };
	class B_mas_usr_Boat_Armed_01_F						{ quality = 1; price = 8200; };
	class B_mas_usn_SDV_01_F							{ quality = 1; price = 8200; };
