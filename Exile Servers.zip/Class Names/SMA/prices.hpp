
////////////////////////////////////////////////////
//SMA 
////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////////////
//WEAPONS
/////////////////////////////////////////////////////////////////////////////////////////////////////////

class SMA_HK416afgQCB                                                   { quality = 1; price = 400; };
class SMA_HK416afg                                                      { quality = 1; price = 400; };
class SMA_HK416vfg                                                      { quality = 1; price = 400; };
class SMA_HK416GL                                                       { quality = 1; price = 400; };
class SMA_HK416afgOD                                                    { quality = 1; price = 400; };
class SMA_HK416MOEOD                                                    { quality = 1; price = 400; };
class SMA_HK416CQBafgOD                                                 { quality = 1; price = 400; };
class SMA_HK416CQBMOEOD                                                 { quality = 1; price = 400; };
class SMA_HK416GLOD                                                     { quality = 1; price = 400; };
class SMA_HK416CQBGLOD                                                  { quality = 1; price = 400; };
class SMA_HK416_afg_ODPAINTED                                           { quality = 1; price = 400; };
class SMA_HK416_GL_ODPAINTED                                            { quality = 1; price = 400; };
class SMA_HK416_vfg_ODPAINTED                                           { quality = 1; price = 400; };
class SMA_HK416CQB_vfg_ODPAINTED                                        { quality = 1; price = 400; };
class SMA_HK416CUSTOMafg                                                { quality = 1; price = 400; };
class SMA_HK416CUSTOMCQBvfg                                             { quality = 1; price = 400; };
class SMA_HK416CUSTOMCQBvfgB                                            { quality = 1; price = 400; };
class SMA_HK416CUSTOMCQBvfgODP                                          { quality = 1; price = 400; };
class SMA_HK416CUSTOMvfg                                                { quality = 1; price = 400; };
class SMA_HK416CUSTOMvfgB                                               { quality = 1; price = 400; };
class SMA_HK416CUSTOMvfgODP                                             { quality = 1; price = 400; };
class SMA_HK416CUSTOMCQBafg                                             { quality = 1; price = 400; };
class SMA_HK416CUSTOMCQBafgB                                            { quality = 1; price = 400; };
class SMA_HK416CUSTOMCQBafgODP                                          { quality = 1; price = 400; };
class SMA_HK416CUSTOMafgB                                               { quality = 1; price = 400; };
class SMA_HK416CUSTOMafgODP                                             { quality = 1; price = 400; };
class SMA_HK416GLCQB                                                    { quality = 1; price = 400; };
class SMA_HK416GLCQB_B                                                  { quality = 1; price = 400; };
class SMA_HK416GLCQB_ODP                                                { quality = 1; price = 400; };
class SMA_HK417                                                         { quality = 1; price = 400; };
class SMA_HK417vfg                                                      { quality = 1; price = 400; };
class SMA_HK417_16in                                                    { quality = 1; price = 400; };
class SMA_SAR21_F                                                       { quality = 1; price = 400; };
class SMA_SAR21MMS_F                                                    { quality = 1; price = 400; };
class SMA_SAR21_AFG_F                                                   { quality = 1; price = 400; };
class SMA_SAR21MMS_AFG_F                                                { quality = 1; price = 400; };
class SMA_SKS_F                                                         { quality = 1; price = 400; };
class SMA_SKS_TAN_F                                                     { quality = 1; price = 400; };
class SMA_STG_E4_F                                                      { quality = 1; price = 400; };
class SMA_STG_E4_BLACK_F                                                { quality = 1; price = 400; };
class SMA_STG_E4_OD_F                                                   { quality = 1; price = 400; };
class SMA_AUG_EGLM                                                      { quality = 1; price = 400; };
class SMA_AUG_A3_F                                                      { quality = 1; price = 400; };
class SMA_AUG_A3_MCAM_F                                                 { quality = 1; price = 400; };
class SMA_AUG_A3_KRYPT_F                                                { quality = 1; price = 400; };
class SMA_AUG_EGLM_Olive                                                { quality = 1; price = 400; };
class SMA_AUG_EGLM_tan                                                  { quality = 1; price = 400; };
class SMA_MK16                                                          { quality = 1; price = 400; };
class SMA_Mk17                                                          { quality = 1; price = 400; };
class SMA_Mk16_EGLM                                                     { quality = 1; price = 400; };
class SMA_Mk17_EGLM                                                     { quality = 1; price = 400; };
class SMA_Mk16_black                                                    { quality = 1; price = 400; };
class SMA_Mk16_Green                                                    { quality = 1; price = 400; };
class SMA_Mk16_blackQCB                                                 { quality = 1; price = 400; };
class SMA_Mk16_GreenQCB                                                 { quality = 1; price = 400; };
class SMA_Mk16QCB                                                       { quality = 1; price = 400; };
class SMA_Mk17_black                                                    { quality = 1; price = 400; };
class SMA_Mk17_Green                                                    { quality = 1; price = 400; };
class SMA_MK16_EGLM_black                                               { quality = 1; price = 400; };
class SMA_MK16_EGLM_Green                                               { quality = 1; price = 400; };
class SMA_MK17_EGLM_black                                               { quality = 1; price = 400; };
class SMA_MK17_EGLM_Green                                               { quality = 1; price = 400; };
class SMA_Mk17_16_black                                                 { quality = 1; price = 400; };
class SMA_Mk17_16_Green                                                 { quality = 1; price = 400; };
class SMA_Mk17_16                                                       { quality = 1; price = 400; };
class SMA_ACR                                                           { quality = 1; price = 400; };
class SMA_ACRblk                                                        { quality = 1; price = 400; };
class SMA_ACRGL                                                         { quality = 1; price = 400; };
class SMA_ACRGL_B                                                       { quality = 1; price = 400; };
class SMA_ACRMOE                                                        { quality = 1; price = 400; };
class SMA_ACRMOE_Blk                                                    { quality = 1; price = 400; };
class SMA_ACRREM                                                        { quality = 1; price = 400; };
class SMA_ACRREMblk                                                     { quality = 1; price = 400; };
class SMA_ACRREMGL                                                      { quality = 1; price = 400; };
class SMA_ACRREMGL_B                                                    { quality = 1; price = 400; };
class SMA_ACRREMCQBGL                                                   { quality = 1; price = 400; };
class SMA_ACRREMCQBGL_B                                                 { quality = 1; price = 400; };
class SMA_ACRREMMOE                                                     { quality = 1; price = 400; };
class SMA_ACRREMMOEblk                                                  { quality = 1; price = 400; };
class SMA_ACRREMMOECQB                                                  { quality = 1; price = 400; };
class SMA_ACRREMMOECQBblk                                               { quality = 1; price = 400; };
class SMA_ACRREMAFG                                                     { quality = 1; price = 400; };
class SMA_ACRREMAFGblk                                                  { quality = 1; price = 400; };
class SMA_ACRREMAFGCQB                                                  { quality = 1; price = 400; };
class SMA_ACRREMAFGCQBblk                                               { quality = 1; price = 400; };
class SMA_ACRREM_N                                                      { quality = 1; price = 400; };
class SMA_ACRREMblk_N                                                   { quality = 1; price = 400; };
class SMA_ACRREMMOE_N                                                   { quality = 1; price = 400; };
class SMA_ACRREMMOEblk_N                                                { quality = 1; price = 400; };
class SMA_ACRREMMOECQB_N                                                { quality = 1; price = 400; };
class SMA_ACRREMMOECQBblk_N                                             { quality = 1; price = 400; };
class SMA_ACRREMAFG_N                                                   { quality = 1; price = 400; };
class SMA_ACRREMAFGblk_N                                                { quality = 1; price = 400; };
class SMA_ACRREMAFGCQB_N                                                { quality = 1; price = 400; };
class SMA_ACRREMAFGCQBblk_N                                             { quality = 1; price = 400; };
class SMA_ACRREMCQBGL_B_N                                               { quality = 1; price = 400; };
class SMA_ACRREMCQBGL_N                                                 { quality = 1; price = 400; };
class SMA_ACRREMGL_B_N                                                  { quality = 1; price = 400; };
class SMA_ACRREMGL_N                                                    { quality = 1; price = 400; };
class Sma_minimi_mk3_762tlb                                             { quality = 1; price = 400; };
class Sma_minimi_mk3_762tlb_des                                         { quality = 1; price = 400; };
class Sma_minimi_mk3_762tlb_wdl                                         { quality = 1; price = 400; };
class Sma_minimi_mk3_762tsb                                             { quality = 1; price = 400; };
class Sma_minimi_mk3_762tsb_des                                         { quality = 1; price = 400; };
class Sma_minimi_mk3_762tsb_wdl                                         { quality = 1; price = 400; };
class SMA_L85RIS                                                        { quality = 1; price = 400; };
class SMA_L85RISNR                                                      { quality = 1; price = 400; };
class SMA_L85RISafg                                                     { quality = 1; price = 400; };
class SMA_L85RISafgNR                                                   { quality = 1; price = 400; };
class SMA_Steyr_AUG_F                                                   { quality = 1; price = 400; };
class SMA_Steyr_AUG_BLACK_F                                             { quality = 1; price = 400; };
class SMA_AAC_MPW_9_Black                                               { quality = 1; price = 400; };
class SMA_AAC_MPW_9_Woodland                                            { quality = 1; price = 400; };
class SMA_AAC_MPW_9_OD                                                  { quality = 1; price = 400; };
class SMA_AAC_MPW_9_Desert                                              { quality = 1; price = 400; };
class SMA_AAC_MPW_9_Tan                                                 { quality = 1; price = 400; };
class SMA_AAC_MPW_12_Black                                              { quality = 1; price = 400; };
class SMA_AAC_MPW_12_Woodland                                           { quality = 1; price = 400; };
class SMA_AAC_MPW_12_OD                                                 { quality = 1; price = 400; };
class SMA_AAC_MPW_12_Desert                                             { quality = 1; price = 400; };
class SMA_AAC_MPW_12_Tan                                                { quality = 1; price = 400; };
class SMA_AAC_MPW_16_Black                                              { quality = 1; price = 400; };
class SMA_AAC_MPW_16_Woodland                                           { quality = 1; price = 400; };
class SMA_AAC_MPW_16_OD                                                 { quality = 1; price = 400; };
class SMA_AAC_MPW_16_Desert                                             { quality = 1; price = 400; };
class SMA_AAC_MPW_16_Tan                                                { quality = 1; price = 400; };
class SMA_AAC_762_sdn6                                                  { quality = 1; price = 400; };
class SMA_AAC_762_sdn6_w                                                { quality = 1; price = 400; };
class SMA_AAC_762_sdn6_d                                                { quality = 1; price = 400; };
class SMA_AAC_762_sdn6_T                                                { quality = 1; price = 400; };
class SMA_AAC_762_sdn6_G                                                { quality = 1; price = 400; };
class SMA_Tavor_F                                                       { quality = 1; price = 400; };
class SMA_TavorOD_F                                                     { quality = 1; price = 400; };
class SMA_TavorBLK_F                                                    { quality = 1; price = 400; };
class SMA_CTAR_F                                                        { quality = 1; price = 400; };
class SMA_CTAROD_F                                                      { quality = 1; price = 400; };
class SMA_CTARBLK_F                                                     { quality = 1; price = 400; };
class SMA_MK18afg                                                       { quality = 1; price = 400; };
class SMA_MK18afg_SM                                                    { quality = 1; price = 400; };
class SMA_MK18afgBLK                                                    { quality = 1; price = 400; };
class SMA_MK18afgODBLK                                                  { quality = 1; price = 400; };
class SMA_MK18afgBLK_SM                                                 { quality = 1; price = 400; };
class SMA_MK18afgODBLK_SM                                               { quality = 1; price = 400; };
class SMA_MK18afgOD                                                     { quality = 1; price = 400; };
class SMA_MK18afgOD_SM                                                  { quality = 1; price = 400; };
class SMA_MK18afgTAN                                                    { quality = 1; price = 400; };
class SMA_MK18afgTAN_SM                                                 { quality = 1; price = 400; };
class SMA_MK18afgTANBLK                                                 { quality = 1; price = 400; };
class SMA_MK18afgTANBLK_SM                                              { quality = 1; price = 400; };
class SMA_MK18MOE                                                       { quality = 1; price = 400; };
class SMA_MK18MOE_SM                                                    { quality = 1; price = 400; };
class SMA_MK18MOETAN                                                    { quality = 1; price = 400; };
class SMA_MK18MOETAN_SM                                                 { quality = 1; price = 400; };
class SMA_MK18MOEBLK                                                    { quality = 1; price = 400; };
class SMA_MK18MOEBLK_SM                                                 { quality = 1; price = 400; };
class SMA_MK18MOEODBLK                                                  { quality = 1; price = 400; };
class SMA_MK18MOEODBLK_SM                                               { quality = 1; price = 400; };
class SMA_MK18MOEOD                                                     { quality = 1; price = 400; };
class SMA_MK18MOEOD_SM                                                  { quality = 1; price = 400; };
class SMA_MK18MOEBLKTAN                                                 { quality = 1; price = 400; };
class SMA_MK18MOEBLKTAN_SM                                              { quality = 1; price = 400; };
class SMA_MK18_GL                                                       { quality = 1; price = 400; };
class SMA_MK18_GL_SM                                                    { quality = 1; price = 400; };
class SMA_MK18TANBLK_GL                                                 { quality = 1; price = 400; };
class SMA_MK18TANBLK_GL_SM                                              { quality = 1; price = 400; };
class SMA_MK18TAN_GL                                                    { quality = 1; price = 400; };
class SMA_MK18TAN_GL_SM                                                 { quality = 1; price = 400; };
class SMA_MK18BLK_GL                                                    { quality = 1; price = 400; };
class SMA_MK18BLK_GL_SM                                                 { quality = 1; price = 400; };
class SMA_MK18ODBLK_GL                                                  { quality = 1; price = 400; };
class SMA_MK18ODBLK_GL_SM                                               { quality = 1; price = 400; };
class SMA_MK18OD_GL                                                     { quality = 1; price = 400; };
class SMA_MK18OD_GL_SM                                                  { quality = 1; price = 400; };
class SMA_M4_GL                                                         { quality = 1; price = 400; };
class SMA_M4_GL_SM                                                      { quality = 1; price = 400; };
class SMA_M4afg                                                         { quality = 1; price = 400; };
class SMA_M4afg_SM                                                      { quality = 1; price = 400; };
class SMA_M4afg_Tan                                                     { quality = 1; price = 400; };
class SMA_M4afg_Tan_SM                                                  { quality = 1; price = 400; };
class SMA_M4afg_OD                                                      { quality = 1; price = 400; };
class SMA_M4afg_OD_SM                                                   { quality = 1; price = 400; };
class SMA_M4afg_BLK1                                                    { quality = 1; price = 400; };
class SMA_M4afg_BLK1_SM                                                 { quality = 1; price = 400; };
class SMA_M4MOE                                                         { quality = 1; price = 400; };
class SMA_M4MOE_SM                                                      { quality = 1; price = 400; };
class SMA_M4MOE_Tan                                                     { quality = 1; price = 400; };
class SMA_M4MOE_Tan_SM                                                  { quality = 1; price = 400; };
class SMA_M4MOE_OD                                                      { quality = 1; price = 400; };
class SMA_M4MOE_OD_SM                                                   { quality = 1; price = 400; };
class SMA_M4MOE_BLK1                                                    { quality = 1; price = 400; };
class SMA_M4MOE_BLK1_SM                                                 { quality = 1; price = 400; };
class SMA_M4afgSTOCK                                                    { quality = 1; price = 400; };
class SMA_M4CQBR                                                        { quality = 1; price = 400; };
class SMA_M4CQBRMOE                                                     { quality = 1; price = 400; };
                 
/////////////////////////////////////////////////////////////////////////////////////////////////////////                                                       
//Scopes           
/////////////////////////////////////////////////////////////////////////////////////////////////////////                                                     
                                                                        
class SMA_ELCAN_SPECTER                                                 { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_TAN                                             { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_GREEN                                           { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_ARDRDS                                          { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_TAN_ARDRDS                                      { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_GREEN_ARDRDS                                    { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_RDS                                             { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_TAN_RDS                                         { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_GREEN_RDS                                       { quality = 1; price = 400; };
class SMA_MICRO_T2                                                      { quality = 1; price = 400; };
class SMA_MICRO_T2_LM                                                   { quality = 1; price = 400; };
class SMA_MICRO_T2_3XDOWN                                               { quality = 1; price = 400; };
class SMA_eotech                                                        { quality = 1; price = 400; };
class SMA_eotech_T                                                      { quality = 1; price = 400; };
class SMA_eotech_G                                                      { quality = 1; price = 400; };
class SMA_eotechG33_3XDOWN                                              { quality = 1; price = 400; };
class SMA_eotechG33_tan_3XDOWN                                          { quality = 1; price = 400; };
class SMA_eotechG33_grn_3XDOWN                                          { quality = 1; price = 400; };
class SMA_eotech552                                                     { quality = 1; price = 400; };
class SMA_eotech552_kf                                                  { quality = 1; price = 400; };
class SMA_eotech552_kf_des                                              { quality = 1; price = 400; };
class SMA_eotech552_kf_wdl                                              { quality = 1; price = 400; };
class SMA_eotech552_3XDOWN                                              { quality = 1; price = 400; };
class SMA_eotech552_3XDOWN_wdl                                          { quality = 1; price = 400; };
class SMA_eotech552_3XDOWN_des                                          { quality = 1; price = 400; };
class Sma_spitfire_01_sc_black                                          { quality = 1; price = 400; };
class Sma_spitfire_01_black                                             { quality = 1; price = 400; };
class Sma_spitfire_03_sc_black                                          { quality = 1; price = 400; };
class Sma_spitfire_03_black                                             { quality = 1; price = 400; };
class Sma_spitfire_03_rds_black                                         { quality = 1; price = 400; };
class Sma_spitfire_03_rds_low_black                                     { quality = 1; price = 400; };
class Sma_spitfire_03_rds_low_ard_black                                 { quality = 1; price = 400; };
class SMA_AIMPOINT                                                      { quality = 1; price = 400; };
class SMA_AIMPOINT_GLARE                                                { quality = 1; price = 400; };
class SMA_BARSKA                                                        { quality = 1; price = 400; };
class SMA_CMORE                                                         { quality = 1; price = 400; };
class SMA_CMOREGRN                                                      { quality = 1; price = 400; };
                                                                    
/////////////////////////////////////////////////////////////////////////////////////////////////////////    
//OPTIONAL
/////////////////////////////////////////////////////////////////////////////////////////////////////////                                                              
                                                                        
class SMA_ELCAN_SPECTER_4z                                              { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_TAN_4z                                          { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_GREEN_4z                                        { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_ARDRDS_4z                                       { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_TAN_ARDRDS_4z                                   { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_GREEN_ARDRDS_4z                                 { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_RDS_4z                                          { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_TAN_RDS_4z                                      { quality = 1; price = 400; };
class SMA_ELCAN_SPECTER_GREEN_RDS_4z                                    { quality = 1; price = 400; };

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//ACC
/////////////////////////////////////////////////////////////////////////////////////////////////////////  
                                              
class SMA_RAILGUARD_OD_HK                                               { quality = 1; price = 400; };
class SMA_RAILGUARD_TAN_HK                                              { quality = 1; price = 400; };
class SMA_RAILGUARD_BLK_HK                                              { quality = 1; price = 400; };
class SMA_ANPEQ15_TAN                                                   { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_TAN                                               { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_417TAN                                            { quality = 1; price = 400; };
class SMA_ANPEQ15_BLK                                                   { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_BLK                                               { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_417BLK                                            { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_TAN_MK18                                          { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_BLK_MK18                                          { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_TAN_M4                                            { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_BLK_M4                                            { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_TAN_SCAR                                          { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_BLK_SCAR                                          { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_TAN_ACR                                           { quality = 1; price = 400; };
class SMA_ANPEQ15_TOP_BLK_ACR                                           { quality = 1; price = 400; };
class SMA_SFFL_TAN                                                      { quality = 1; price = 400; };
class SMA_SFFL_BLK                                                      { quality = 1; price = 400; };
class SMA_SFPEQ_M4TOP_TAN                                               { quality = 1; price = 400; };
class SMA_SFPEQ_M4TOP_BLK                                               { quality = 1; price = 400; };
class SMA_SFPEQ_MK18TOP_TAN                                             { quality = 1; price = 400; };
class SMA_SFPEQ_MK18TOP_BLK                                             { quality = 1; price = 400; };
class SMA_SFPEQ_HKTOP_TAN                                               { quality = 1; price = 400; };
class SMA_SFPEQ_HKTOP_BLK                                               { quality = 1; price = 400; };
class SMA_SFPEQ_HK417TOP_TAN                                            { quality = 1; price = 400; };
class SMA_SFPEQ_HK417TOP_BLK                                            { quality = 1; price = 400; };
class SMA_SFPEQ_SCARTOP_TAN                                             { quality = 1; price = 400; };
class SMA_SFPEQ_SCARTOP_BLK                                             { quality = 1; price = 400; };
class SMA_SFPEQ_ACRTOP_BLK                                              { quality = 1; price = 400; };
class SMA_SFPEQ_ACRTOP_BLK_LIGHT                                        { quality = 1; price = 400; };
class SMA_SFPEQ_ACRTOP_TAN                                              { quality = 1; price = 400; };
class SMA_SFPEQ_ACRTOP_TAN_LIGHT                                        { quality = 1; price = 400; };
class SMA_SFPEQ_AUGCQC_TAN                                              { quality = 1; price = 400; };
class SMA_SFPEQ_AUGCQC_BLK                                              { quality = 1; price = 400; };
class SMA_Gripod_01                                                     { quality = 1; price = 400; };

/////////////////////////////////////////////////////////////////////////////////////////////////////////                                                                           
//Supressors                                                           
/////////////////////////////////////////////////////////////////////////////////////////////////////////    
                                                                       
class SMA_FLASHHIDER1                                                   { quality = 1; price = 400; };
class SMA_FLASHHIDER2                                                   { quality = 1; price = 400; };
class Sma_gemtech_one_blk                                               { quality = 1; price = 400; };
class Sma_gemtech_one_des                                               { quality = 1; price = 400; };
class Sma_gemtech_one_wdl                                               { quality = 1; price = 400; };
class SMA_Silencer_556                                                  { quality = 1; price = 400; };
class SMA_Silencer_556_Bronze                                           { quality = 1; price = 400; };
class SMA_Silencer_556_Silver                                           { quality = 1; price = 400; };
class SMA_supp1b_556                                                    { quality = 1; price = 400; };
class SMA_supp1tan_556                                                  { quality = 1; price = 400; };
class SMA_supp2b_556                                                    { quality = 1; price = 400; };
class SMA_supp2btan_556                                                 { quality = 1; price = 400; };
class SMA_supp_762                                                      { quality = 1; price = 400; };
class SMA_supptan_762                                                   { quality = 1; price = 400; };
class SMA_supp1BB_556                                                   { quality = 1; price = 400; };
class SMA_supp1BOD_556                                                  { quality = 1; price = 400; };
class SMA_supp1BT_556                                                   { quality = 1; price = 400; };
class SMA_supp1Bwht_556                                                 { quality = 1; price = 400; };
class SMA_supp1TB_556                                                   { quality = 1; price = 400; };
class SMA_supp1TOD_556                                                  { quality = 1; price = 400; };
class SMA_supp1TT_556                                                   { quality = 1; price = 400; };
class SMA_supp1TW_556                                                   { quality = 1; price = 400; };
class SMA_supp2BOD_556                                                  { quality = 1; price = 400; };
class SMA_supp2BT_556                                                   { quality = 1; price = 400; };
class SMA_supp2BW_556                                                   { quality = 1; price = 400; };
class SMA_supp2T_556                                                    { quality = 1; price = 400; };
class SMA_supp2TB_556                                                   { quality = 1; price = 400; };
class SMA_supp2TOD_556                                                  { quality = 1; price = 400; };
class SMA_supp2TWH_556                                                  { quality = 1; price = 400; };
class SMA_supp2smaB_556                                                 { quality = 1; price = 400; };
class SMA_supp2smaT_556                                                 { quality = 1; price = 400; };
class SMA_rotex_blk                                                     { quality = 1; price = 400; };
class SMA_rotex_tan                                                     { quality = 1; price = 400; };
class SMA_rotex_gry                                                     { quality = 1; price = 400; };
class SMA_AAC_762_sdn6                                                  { quality = 1; price = 400; };
class SMA_AAC_762_sdn6_w                                                { quality = 1; price = 400; };
class SMA_AAC_762_sdn6_d                                                { quality = 1; price = 400; };

/////////////////////////////////////////////////////////////////////////////////////////////////////////                                                                        
//Ammo                                                                  
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                        
class SMA_30Rnd_762x35_BLK_EPR                                          { quality = 1; price = 400; };
class SMA_30Rnd_762x35_SS                                               { quality = 1; price = 400; };
class SMA_30Rnd_762x39_SKS_FMJ                                          { quality = 1; price = 400; };
class SMA_30Rnd_762x39_SKS_FMJ_Red                                      { quality = 1; price = 400; };
class SMA_30Rnd_762x39_SKS_7n23_AP                                      { quality = 1; price = 400; };
class SMA_30Rnd_762x39_7n23_AP_Red                                      { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_M80A1_EPR                                      { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_M80A1_EPR_Tracer                               { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_M80A1_EPR_IR                                   { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_Mk316_Mod_0_Special_Long_Range                 { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_Mk316_Mod_0_Special_Long_Range_Tracer          { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_Mk316_Mod_0_Special_Long_Range_IR              { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_Lapua_FMJ_Subsonic                             { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_Lapua_FMJ_Subsonic_Tracer                      { quality = 1; price = 400; };
class SMA_20Rnd_762x51mm_Lapua_FMJ_Subsonic_IR                          { quality = 1; price = 400; };
class SMA_30Rnd_556x45_M855A1                                           { quality = 1; price = 400; };
class SMA_30Rnd_556x45_M855A1_Tracer                                    { quality = 1; price = 400; };
class SMA_30Rnd_556x45_M855A1_IR                                        { quality = 1; price = 400; };
class SMA_30Rnd_556x45_Mk318                                            { quality = 1; price = 400; };
class SMA_30Rnd_556x45_Mk318_Tracer                                     { quality = 1; price = 400; };
class SMA_30Rnd_556x45_Mk318_IR                                         { quality = 1; price = 400; };
class SMA_30Rnd_556x45_Mk262                                            { quality = 1; price = 400; };
class SMA_30Rnd_556x45_Mk262_Tracer                                     { quality = 1; price = 400; };
class SMA_30Rnd_556x45_Mk262_IR                                         { quality = 1; price = 400; };
class SMA_30Rnd_68x43_SPC_FMJ                                           { quality = 1; price = 400; };
class SMA_30Rnd_68x43_SPC_FMJ_Tracer                                    { quality = 1; price = 400; };
class SMA_30Rnd_68x43_SPC_FMJ_IR                                        { quality = 1; price = 400; };
class SMA_30Rnd_68x43_BT                                                { quality = 1; price = 400; };
class SMA_30Rnd_68x43_BT_Tracer                                         { quality = 1; price = 400; };
class SMA_30Rnd_68x43_BT_IR                                             { quality = 1; price = 400; };
class SMA_30Rnd_68x43_sub                                               { quality = 1; price = 400; };
class SMA_30Rnd_68x43_sub_Tracer                                        { quality = 1; price = 400; };
class SMA_30Rnd_68x43_sub_IR                                            { quality = 1; price = 400; };
class SMA_150Rnd_762_M80A1                                              { quality = 1; price = 400; };
class SMA_150Rnd_762_M80A1_Tracer                                       { quality = 1; price = 400; };
class SMA_150Rnd_762_M80A1_Mixed                                        { quality = 1; price = 400; };


