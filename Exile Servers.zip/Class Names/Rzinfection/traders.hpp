	class Rzinfection
	{
		name = "Rzinfection";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{			
			"rzinfection_antivirus_injector",
			"rzinfection_antivirus_pills"
		};
	};